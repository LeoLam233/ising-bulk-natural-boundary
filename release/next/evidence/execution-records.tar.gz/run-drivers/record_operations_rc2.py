"""Preserve failed command outcomes and explicitly scoped interactive observations."""
from pathlib import Path
import datetime, json, subprocess

w=Path(__file__).resolve().parent
r=w.parent/'repo'
failures=[]
for name in ('fetch-review-journal-curl','fetch-review-journal-http','regression-historical','repository-guard-controls','whitespace-before-final-fix'):
    record=json.loads((w/'logs'/(name+'.json')).read_text())
    assert record['exit_code']!=0
    failures.append(dict(name=name,command_receipt='logs/'+name+'.json',
                         exit_code=record['exit_code'],started_utc=record['started_utc']))
observations=[
    'The preflight ledger description said 31 after adding row 32. Corrected before the final accepted preflight; both receipts are retained.',
    'An interim semantic-only verifier probe found a missing link to the not-yet-created rc2 consistency report. After creating the draft report the same semantic check passed. These are interactive observations, not archived full-verifier executions.',
    'The preliminary arXiv source-extraction driver used zero-index page 8 for (45). Corrected to page 7, in agreement with the already correct committed source index. The first extraction receipt remains; a fresh correction receipt records the rerun.',
    'The prebuild production control suite has 12 cases. The postbuild --shadow-tree variant has 13. A progress message initially conflated these counts and was corrected. No prebuild 13-case result is claimed.',
    'Generated candidate JSON had CRLF formatting warnings. Current generated metadata was normalized to LF before final acceptance; compiled PDF bytes were unchanged.',
    'The first successful isolated repository controls hashed seven critical inputs. That receipt is retained as a bounded-input run. The final run adds a complete tracked/unignored before/after inventory and binds the control script itself; all five attacks and positive controls are rerun. Only the final full-tree receipt supports the current tree-unchanged claim.',
    'Direct original Nickel publisher access returned an HTML challenge rather than paper content. No challenge was solved. Clean host-only access metadata is retained; redirect challenge parameters and third-party reading copies are not distributed.',
]
result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            scope='Actual failed command receipts plus clearly identified interactive run notes; not reconstructed command output.',
            failed_commands=failures,interactive_observations=observations)
(w/'observed-operations.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
old=r/'release/next/FAILURES.md'
data=subprocess.check_output(['git','-c','safe.directory=*','show',
    'dd977048c2380e775d83b97ae1fba354c04c349a:release/next/FAILURES.md'],cwd=r)
assert old.read_bytes().endswith(data), 'Original rc1 record must remain an exact suffix'
prefix='''# rc6 / Lean v0.3.0-rc2 run: failures and evidence limits

The following records concern the amplitude research run. The original rc5 failure record is preserved verbatim below; its archive links and source-access statements describe the immutable `dd977048` tree, not the current archive. Current source access is documented in `checks/amplitude_identification/SOURCES.json`.

| Attempt | Actual outcome | Resolution / evidence scope |
|---|---|---|
| `fetch-review-journal-curl`, `fetch-review-journal-http` | Both Windows curl attempts exited 60 (`SEC_E_UNTRUSTED_ROOT`). The HTTP endpoint redirects to HTTPS. | The ordinary WSL trust store retrieved the institutional journal PDF successfully. TLS verification was never disabled. All command streams and the clean successful access record are retained. |
| `regression-historical` | Exit 2: `reproduce.py` does not accept `--output`. No diagnostic ran in this failed invocation. | Reran its supported command as `regression-historical-02`; all six diagnostics reproduced. The failure and success streams remain separate. |
| Original Nickel 1999/2000 access | Web reader errors or HTTP 200 HTML challenge, including the normal browser. | No original paper text was available, and no challenge was solved. No original intended amplitude convention or original-paper error is attributed. The inspected review and cited integral suffice for the stated mathematical conversion. |
| Intermediate source locator, document count, and semantic probe | A scratch source extractor pointed to arXiv page 8 instead of 7; a correspondence sentence said 31 rows after adding row 32; a semantic probe encountered the consistency report before it existed. | Corrected source locator and reran extraction. Fixed row count before freezing verification inputs and reran preflight. Created the audit record and reran semantic checks. Original command receipts, where present, are retained; interactive observations are explicitly identified as such. |
| Prebuild control-count progress wording | A progress message called the prebuild production suite 13 cases. Its actual result is 12. | Corrected the message and current reproduction instructions. The complete postbuild `--shadow-tree` suite executes the 13th namespace-rejection case. Counts are read from the executed receipts. |
| Candidate metadata whitespace | Generated JSON initially used CRLF. | Normalized current generated metadata to LF; manuscript PDF and original executed streams are unchanged. Historical preserved files keep their original bytes. |
| First isolated repository-control launch | Wrapper exit 1 because its local Git clone subprocess exited 128 inside the Windows process sandbox. No consistency negative was executed in that failed invocation. | Reran with authorized native execution; all five expected rejections and positive controls passed. The failed launch receipt remains separate. |
| Isolated-control unchanged-input scope | The first successful run hashed seven critical inputs; its historical `input_tree_unchanged` field must be read with that bounded scope. | Added complete tracked/unignored before/after file inventories, included the control script among persistent critical inputs, and reran all five controls with a fresh output path. The final full-tree receipt is the current authority; the earlier result is retained separately. |
| Final staged whitespace check | Git exit 2: the generated rc2 audit report had an extra blank line at EOF. | Removed that blank line, corrected the report writer, and reran whitespace and final candidate checks. No mathematical or Lean input changed. |

The current raw archive contains the failed command receipts and `source-reading/observed-operations.json`. It excludes publisher challenge parameters and third-party PDFs. Exact symbolic identities, finite cyclotomic enumeration, numerical quadratures and samples do not certify continuous remainders or an infinite sum; those claims rely on the stated manuscript arguments. Proposition F.1 and the radial Taylor reconstruction are manuscript-only. The formal gate uses the pinned official Lean kernel; no second kernel implementation, complete Mathlib source rebuild, independent human validation or exhaustive novelty clearance is claimed.

---

'''.encode()
old.write_bytes(prefix+data)
print(json.dumps({'failed_command_receipts':len(failures),'interactive_observations':len(observations),'historical_failure_record_preserved_as_suffix':True}))
