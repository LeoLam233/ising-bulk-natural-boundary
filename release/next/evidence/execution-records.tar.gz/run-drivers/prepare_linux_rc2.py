from pathlib import Path
import json, shutil
source=Path('/mnt/i/Codex/_Projectless/2026-10-17/ising-bulk-natural-boundary-autonomous-research-2/work/repo/lean')
dest=Path('/tmp/ising-amplitude-rc2-20261017-a1/lean')
assert not dest.exists()
dest.parent.mkdir(parents=True,exist_ok=False)
shutil.copytree(source,dest,ignore=shutil.ignore_patterns('.lake','__pycache__','.local','results'))
(dest/'.lake').mkdir()
cache=Path('/tmp/ising-next-20261017-a2/lean/.lake/packages')
assert cache.is_dir()
(dest/'.lake/packages').symlink_to(cache,target_is_directory=True)
print(json.dumps({'fresh_project':str(dest),'dependency_cache':str(cache),
                  'project_build_outputs_present':(dest/'.lake/build').exists()}))
