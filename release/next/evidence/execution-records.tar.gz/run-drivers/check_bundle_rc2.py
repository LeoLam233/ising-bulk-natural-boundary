"""Verify and clone the full delivered Git bundle into a fresh Linux checkout."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess

w=Path(__file__).resolve().parent
repo=w.parent/'repo';bundle=w.parents[1]/'outputs/amplitude-rc6/Ising_v0.3.0-rc2_Candidate.bundle'
dest=Path('/tmp/ising-rc2-bundle-check-20261017')
assert os.name=='posix' and not dest.exists() and bundle.is_file()
logs=w/'logs/bundle-checkout';logs.mkdir(exist_ok=False)
records=[]
def run(name,argv,cwd):
    s=subprocess.run(argv,cwd=cwd,capture_output=True,text=True,encoding='utf-8',timeout=180)
    (logs/(name+'.stdout')).write_text(s.stdout,encoding='utf-8')
    (logs/(name+'.stderr')).write_text(s.stderr,encoding='utf-8')
    records.append(dict(stage=name,argv=argv,cwd=str(cwd),exit_code=s.returncode))
    assert s.returncode==0,(name,s.stdout,s.stderr)
    return s.stdout
git=lambda *args:['git','-c','safe.directory=*',*args]
run('bundle_verify',git('bundle','verify',str(bundle)),repo)
run('clone',git('clone','--quiet','--branch','research/next-internal-regularity-20261017',str(bundle),str(dest)),w)
head=run('head',git('rev-parse','HEAD'),dest).strip()
assert head==subprocess.check_output(git('rev-parse','HEAD'),cwd=repo,text=True).strip()
tree=run('tree',git('rev-parse','HEAD^{tree}'),dest).strip()
guard=json.loads(run('candidate_guard',['python3','scripts/verify_candidate.py'],dest))
assert guard['status']=='VERIFIED_CANDIDATE'
assert not run('clean_status',git('status','--porcelain=v1'),dest).strip()
for ref,expected in [('main','84e528bde0da0990f203e36c1b5d92430bda1637'),
                     ('v0.1-rc4','1b4b506c9cb19d5fdbf9f59d89c7a179739d337d'),
                     ('v0.2.1','de23d9475744fb4625666142d5a03b3d688195e6')]:
    local_ref='origin/'+ref if ref=='main' else ref+'^{}'
    assert run('ref_'+ref.replace('/','_'),git('rev-parse',local_ref),dest).strip()==expected
result=dict(bundle_verified=True,head=head,tree=tree,clean_clone=True,fresh_checkout=str(dest),
    bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),candidate_guard=guard,
    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=records,
    scope='Fresh offline Linux Git checkout and repository consistency; no second Lean build/kernel implementation is claimed.')
(w/'bundle-checkout-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
