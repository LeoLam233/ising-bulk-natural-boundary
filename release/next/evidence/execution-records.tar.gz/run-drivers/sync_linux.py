from pathlib import Path
import shutil
source=Path('/mnt/i/Codex/_Projectless/2026-10-17/ising-bulk-natural-boundary-autonomous-research-2/work/repo/lean')
dest=Path('/tmp/ising-next-20261017-a2/lean')
assert dest.is_dir()
changed=[]
for p in source.rglob('*'):
    rel=p.relative_to(source)
    if not p.is_file() or {'.git','.lake','__pycache__'}.intersection(rel.parts):
        continue
    q=dest/rel
    if not q.is_file() or q.read_bytes()!=p.read_bytes():
        q.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,q)
        changed.append(str(rel))
print('Synced '+str(len(changed))+' files: '+', '.join(changed))
