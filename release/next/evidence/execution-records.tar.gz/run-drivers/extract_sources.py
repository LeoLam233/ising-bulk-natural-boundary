"""Extract scratch source pages and bind page/equation locators to PDF hashes."""
import hashlib, json, pathlib
from pypdf import PdfReader

root = pathlib.Path(__file__).resolve().parent
locators = {
    'review-arxiv-v1.pdf': [(7, '(44)-(45), printed 8'), (10, '(64), printed 11'), (11, '(67)-(70), printed 12')],
    'review-journal-wsl.pdf': [(7, '(44)-(45), printed 798'), (9, '(64)-(66), printed 800'), (10, '(67)-(71), printed 801')],
    'boukraa-arxiv-v1.pdf': [(1, '(2)-(7), printed 2'), (2, '(8)-(9), printed 3')],
    'orrick-2001-v1.pdf': [(2, '(1.8), printed 3'), (3, '(1.9)-(1.13), printed 4'),
                          (11, '(3.12)-(3.13), printed 12'), (12, '(3.17)-(3.20), printed 13'),
                          (13, '(3.23)-(3.25), printed 14'), (14, '(3.26)-(3.27), printed 15')],
}
inventory = []
for name, pages in locators.items():
    path = root / name
    reader = PdfReader(path)
    pieces = []
    for index, purpose in pages:
        pieces.append(f'===== ZERO-INDEX PAGE {index}; {purpose} =====\n' + reader.pages[index].extract_text())
    (root/(path.stem+'.selected-pages.txt')).write_text('\n\n'.join(pieces)+'\n', encoding='utf-8')
    inventory.append(dict(file=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                          pages=len(reader.pages), inspected_page_locators=pages))
(root/'source-page-index.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
print(json.dumps(inventory,indent=2))
