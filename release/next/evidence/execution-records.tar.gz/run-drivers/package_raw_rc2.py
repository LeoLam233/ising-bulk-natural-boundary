"""Package executed streams only; third-party reading copies are excluded."""
from pathlib import Path
import datetime, hashlib, json, shutil, tarfile

work=Path(__file__).resolve().parent
repo=work.parent/'repo'
logs=work/'logs'
seq=json.loads((logs/'acceptance-rc2-01/full/sequence.result.json').read_text())
assert seq['status']=='CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND'
assert json.loads((logs/'acceptance-rc2-01/summary.json').read_text())['all_executed_stages_passed']
linux=work/'linux-evidence-rc2'
assert linux.is_dir()
out=repo/'release/next/evidence';out.mkdir(exist_ok=True)
control=linux/'control_packet/continuation/results'
manifest=next(control.glob('manifest-*/summary.json'))
production=next(p for p in control.glob('remediation-*/summary.json') if json.loads(p.read_text())['case_count']==13)
ordinary=next(control.glob('lean-*/summary.json'))
unused=next((linux/'.local').glob('unused-e3-control-*/result.json'))
hist=repo/'.local/checks-3g77c3uj'
paper=repo/json.loads((repo/'paper/next/BUILD.json').read_text())['log_directory']
copies={
    'clean-sequence.json':logs/'acceptance-rc2-01/full/sequence.result.json',
    'acceptance-summary.json':logs/'acceptance-rc2-01/summary.json',
    'manifest-controls.json':manifest,'production-controls-13.json':production,
    'lean-controls-7.json':ordinary,'unused-E3-control.json':unused,
    'historical-diagnostics.json':hist/'REPRODUCTION_RECORD.json',
    'new-mathematical-checks.json':repo/'.local/rc6-next-checks-final.json',
    'amplitude-checks.json':repo/'.local/amplitude-identification-final.json',
}
for name,source in copies.items():
    assert source.is_file(),source
    shutil.copyfile(source,out/name)
sources={}
for directory,prefix in [(logs,'logs'),(linux,'linux-controls'),(hist,'historical-diagnostics'),(paper,'paper-build')]:
    for p in directory.rglob('*'):
        if p.is_file():
            # This exploratory fetch printed publisher challenge redirect
            # parameters. Keep its original private scratch receipt, but do not
            # redistribute those parameters. The clean WSL record is included.
            if directory==logs and p.name.startswith('fetch-primary-sources.'):continue
            sources[prefix+'/'+p.relative_to(directory).as_posix()]=p
for p in (work/'pdfqa-rc6').glob('contact-*.png'):sources['pdf-qa/'+p.name]=p
for p in work.glob('*.py'):
    if p.name.startswith('download_'):continue  # Never publish temporary signed-download helpers.
    sources['run-drivers/'+p.name]=p
for name in ('source-retrieval-wsl.json','observed-operations.json'):
    if (work/name).is_file():sources['source-reading/'+name]=work/name
sources['source-reading/SOURCES.json']=repo/'checks/amplitude_identification/SOURCES.json'
sources['executed-math-script/check_amplitude.py']=repo/'checks/amplitude_identification/check_amplitude.py'
if (work/'phase-coordinate-results.json').is_file():sources['additional-math/phase-coordinate-results.json']=work/'phase-coordinate-results.json'
sources['executed-math-script/retained_rc5_run_checks.py']=repo/'checks/next_version/run_checks.py'
for name in ('rc2-post-validation-scan.json','rc2-final-text-scan.json','repository-controls.json','repository-controls-full-tree.json'):
    if (repo/'.local'/name).is_file():sources['final-checks/'+name]=repo/'.local'/name
# Include the small isolated-control command streams without duplicating its
# full cloned repository or old object database.
for directory in (repo/'.local').glob('rc2-repository-controls-*'):
    for p in directory.iterdir():
        if p.is_file() and p.suffix in ('.stdout','.stderr','.json'):
            sources['repository-controls/'+directory.name+'/'+p.name]=p
entries=[dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
         for name,p in sorted(sources.items())]
archive=out/'execution-records.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for name,p in sorted(sources.items()):tar.add(p,arcname=name,recursive=False)
index=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=archive.name,
           bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=entries,
           scope='Executed rc6/rc2 streams, command receipts, failures, controls, diagnostics and own-manuscript QA, together with reproduction-helper source. No third-party PDF, complete cloned repository, dependency binary tree or publisher challenge parameters.',
           driver_execution_status='Helper-source inclusion alone is not an execution claim. Actual command receipts and result files determine which commands/checks ran; later transport drivers may be included before execution.')
(out/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archived_files':len(entries),'bytes':index['bytes'],'sha256':index['sha256']},indent=2))
