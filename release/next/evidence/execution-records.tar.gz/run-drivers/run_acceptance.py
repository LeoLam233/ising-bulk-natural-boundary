from pathlib import Path
import datetime,json,subprocess,time
root=Path('/tmp/ising-next-final-20261017-a2/lean')
logs=Path('/mnt/i/Codex/_Projectless/2026-10-17/ising-bulk-natural-boundary-autonomous-research-2/work/logs/acceptance-02')
logs.mkdir(parents=True,exist_ok=False)
runtime=Path('/home/ldh/.elan/toolchains/leanprover--lean4---v4.34.1/bin')
records=[]
def run(name,argv):
    print('START',name,flush=True);t=time.monotonic()
    with (logs/(name+'.stdout')).open('wb') as out,(logs/(name+'.stderr')).open('wb') as err:
        p=subprocess.run(argv,cwd=root,stdout=out,stderr=err)
    rec={'stage':name,'argv':argv,'exit_code':p.returncode,'seconds':round(time.monotonic()-t,3)}
    records.append(rec)
    with (logs/(name+'.command-result.json')).open('x') as f:
        f.write(json.dumps(rec,indent=2)+'\n')
    print(json.dumps(rec),flush=True)
    if p.returncode:raise SystemExit('Failed: '+name)
preflight=logs/'input-preflight.json'
run('preflight',['python3','tools/continuation/preflight.py','--lean-bin',str(runtime),'--output',str(preflight)])
expected=json.loads((root/'ci/accepted_identity.json').read_text())
actual=json.loads(preflight.read_text())
assert all(actual[k]==v for k,v in expected.items()),'Reviewed identity mismatch'
run('payload_before',['python3','ci/verify_payload.py','--expected-id',expected['PROOF_CRITICAL_PAYLOAD_ID'],'--dependencies'])
run('manifest_controls',['python3','control_packet/continuation/run_manifest_controls.py'])
run('production_controls',['python3','control_packet/continuation/run_remediation_controls.py'])
run('full_gate',['python3','-u','tools/continuation/final_gate.py','--lean-bin',str(runtime),
                 '--approved-preflight',str(preflight),'--logs',str(logs/'full'),'--threads','2','--execute'])
run('payload_after',['python3','ci/verify_payload.py','--expected-id',expected['PROOF_CRITICAL_PAYLOAD_ID'],'--dependencies'])
summary={'all_executed_stages_passed':True,'identities':expected,'stages':records,
         'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(logs/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('ACCEPTANCE_SEQUENCE_COMPLETED',flush=True)
