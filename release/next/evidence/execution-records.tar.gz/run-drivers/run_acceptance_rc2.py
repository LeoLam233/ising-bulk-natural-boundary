from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, time

work=Path(__file__).resolve().parent
source=work.parent/'repo/lean'
root=Path('/tmp/ising-amplitude-rc2-20261017-a1/lean')
logs=work/'logs/acceptance-rc2-01'
logs.mkdir(exist_ok=False)
runtime=Path('/home/ldh/.elan/toolchains/leanprover--lean4---v4.34.1/bin')
assert os.geteuid()!=0, 'Run production permission controls as the ordinary WSL user'
for name in ('ci/accepted_identity.json','ci/payload.json'):
    shutil.copyfile(source/name,root/name)
records=[]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,argv):
    print('START',name,flush=True)
    started=now();t=time.monotonic()
    out,err=logs/(name+'.stdout'),logs/(name+'.stderr')
    with out.open('xb') as so,err.open('xb') as se:
        result=subprocess.run(argv,cwd=root,stdout=so,stderr=se)
    record=dict(stage=name,argv=argv,cwd=str(root),started_utc=started,finished_utc=now(),
                exit_code=result.returncode,seconds=round(time.monotonic()-t,3),
                stdout_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                stderr_sha256=hashlib.sha256(err.read_bytes()).hexdigest())
    records.append(record)
    (logs/(name+'.command-result.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if result.returncode:raise SystemExit('Failed stage: '+name)

preflight=logs/'input-preflight.json'
run('preflight',['python3','tools/continuation/preflight.py','--lean-bin',str(runtime),'--output',str(preflight)])
expected=json.loads((root/'ci/accepted_identity.json').read_text())
actual=json.loads(preflight.read_text())
assert all(actual[k]==v for k,v in expected.items()),'Input identity changed'
run('payload_before',['python3','ci/verify_payload.py','--expected-id',expected['PROOF_CRITICAL_PAYLOAD_ID'],'--dependencies'])
run('manifest_controls',['python3','control_packet/continuation/run_manifest_controls.py'])
run('production_controls',['python3','control_packet/continuation/run_remediation_controls.py'])
run('full_gate',['python3','-u','tools/continuation/final_gate.py','--lean-bin',str(runtime),
                 '--approved-preflight',str(preflight),'--logs',str(logs/'full'),'--threads','2','--execute'])
run('payload_after',['python3','ci/verify_payload.py','--expected-id',expected['PROOF_CRITICAL_PAYLOAD_ID'],'--dependencies'])
run('compiled_namespace_controls',['python3','control_packet/continuation/run_remediation_controls.py',
                                    '--shadow-tree','.lake/build/lib/lean/IsingBulk'])
(logs/'summary.json').write_text(json.dumps(dict(all_executed_stages_passed=True,identities=expected,
    stages=records,finished_utc=now(),unprivileged_uid=os.geteuid()),indent=2)+'\n')
print('ACCEPTANCE_SEQUENCE_COMPLETED',flush=True)
