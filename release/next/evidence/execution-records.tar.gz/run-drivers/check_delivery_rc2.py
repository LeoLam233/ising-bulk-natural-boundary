"""Check delivered file identities, local links and execution archives."""
from pathlib import Path
import hashlib, json, re, tarfile

out=Path(__file__).resolve().parents[2]/'outputs/amplitude-rc6'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=read(out/'DELIVERY_MANIFEST.json')
actual={p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file() and p.name!='DELIVERY_MANIFEST.json'}
assert actual=={e['path'] for e in m['files']}
for e in m['files']:
    p=out/e['path'];assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(out)
    assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],e['path']
for p in out.rglob('*.md'):
    for t in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if re.match(r'^[A-Za-z]+:',t) or t.startswith('#'):continue
        assert (p.parent/t.split('#')[0]).exists(),(p,t)
assert not any(p.suffix in {'.aux','.log','.out'} for p in out.rglob('*') if p.is_file())
build=read(out/'paper/next/BUILD.json')
assert sha(out/'paper/next/manuscript.tex')==build['source_sha256']
assert sha(out/'paper/next/manuscript.pdf')==build['pdf_sha256']
remote=read(out/'REMOTE_CI_RESULT.json')
assert remote['remote_artifact_verified'] and remote['head']==m['head']
assert sha(out/'Ising_v0.3.0-rc2_Remote_CI.zip')==remote['artifact_sha256']
assert sha(out/'Ising_v0.3.0-rc2_Candidate.bundle')==read(out/'BUNDLE_CHECKOUT_RESULT.json')['bundle_sha256']
for archive,index in [('release/next/evidence/execution-records.tar.gz','release/next/evidence/INDEX.json'),
                       ('FINAL_EXECUTION_RECORDS.tar.gz','FINAL_EXECUTION_INDEX.json')]:
    idx=read(out/index);expected={e['path']:e for e in idx['files']}
    assert sha(out/archive)==idx['sha256']
    with tarfile.open(out/archive,'r:gz') as tar:
        members=tar.getmembers();assert len(members)==len(expected)
        for member in members:
            assert member.isfile() and member.name in expected
            data=tar.extractfile(member).read();e=expected[member.name]
            assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
assert m['both_remote_workflows_passed'] and m['remote_artifact_verified']
assert read(out/'release/next/CONSISTENCY_RESULT.json')['status']=='POST_VALIDATION_AUDIT_COMPLETED'
print(json.dumps(dict(head=m['head'],delivered_files_excluding_manifest=len(actual),
    all_file_hashes_match=True,all_local_links_resolve=True,both_execution_archives_verified=True,
    exact_head_remote_artifact_verified=True,offline_bundle_checkout_verified=True,
    transient_TeX_files_excluded=True),indent=2))
