"""Copy executed Linux controls without their throwaway source/compiled trees."""
from pathlib import Path
import hashlib,json,shutil

project=Path('/tmp/ising-next-final-20261017-a2/lean')
target=Path('/mnt/i/Codex/_Projectless/2026-10-17/ising-bulk-natural-boundary-autonomous-research-2/work/linux-evidence')
target.mkdir(exist_ok=False)
items=[]
sources=[]
for p in (project/'control_packet/continuation/results').rglob('*'):
    if p.is_file() and 'payload' not in p.relative_to(project).parts:
        sources.append(p)
for d in (project/'.local').glob('unused-e3-control-*'):
    sources.extend(p for p in d.rglob('*') if p.is_file())
for p in sorted(sources):
    rel=p.relative_to(project)
    out=target/rel;out.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,out)
    items.append({'path':rel.as_posix(),'bytes':p.stat().st_size,
                  'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(target/'INDEX.json').write_text(json.dumps({'source_project':str(project),
  'scope':'Executed fixture/verifier receipts only; temporary payload copies and compiled trees omitted.',
  'files':items},indent=2)+'\n')
print(json.dumps({'copied_files':len(items),'destination':str(target)},indent=2))
