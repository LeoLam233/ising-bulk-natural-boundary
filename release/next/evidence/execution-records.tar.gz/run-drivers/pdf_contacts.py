from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
from pypdf import PdfReader
root=Path(__file__).parent
pages=sorted((root/'pdfqa').glob('page-*.png'))
for group in range((len(pages)+8)//9):
    sheet=Image.new('RGB',(1530,2040),'#d8d8d8')
    draw=ImageDraw.Draw(sheet)
    for j,p in enumerate(pages[group*9:group*9+9]):
        im=Image.open(p).convert('RGB')
        im.thumbnail((490,650))
        x=(j%3)*510+(510-im.width)//2;y=(j//3)*680+22
        sheet.paste(im,(x,y));draw.text((x,y-17),p.stem,fill='black')
    sheet.save(root/'pdfqa'/f'contact-{group+1}.png')
reader=PdfReader(root/'repo/paper/next/manuscript.pdf')
hits={}
for i,p in enumerate(reader.pages):
    text=p.extract_text()
    for key in ('Internal lower-order','uniform mixed-pair','No smooth extension','Closed form of the same','Rc5 internal regularity'):
        if key in text:hits[key]=i+1
print({'pages':len(reader.pages),'contacts':(len(pages)+8)//9,'changed_page_hits':hits})
