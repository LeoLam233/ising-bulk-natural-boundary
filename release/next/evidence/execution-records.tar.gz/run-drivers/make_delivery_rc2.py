"""Copy the verified candidate into its own output folder, preserving rc1 outputs."""
from pathlib import Path
import datetime, hashlib, json, posixpath, re, shutil, subprocess, tarfile

w=Path(__file__).resolve().parent;r=w.parent/'repo';out=w.parents[1]/'outputs/amplitude-rc6'
out.mkdir(exist_ok=True)
assert not (out/'DELIVERY_MANIFEST.json').exists(),'Use a new delivery folder rather than overwrite a delivered candidate'
git=lambda *args:subprocess.check_output(['git','-c','safe.directory=*',*args],cwd=r,text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
assert not git('status','--porcelain=v1')
assert git('rev-parse','research/amplitude-identification-20261017')==head
assert git('rev-parse','research/next-internal-regularity-20261017')==head
assert git('rev-parse','main')=='84e528bde0da0990f203e36c1b5d92430bda1637'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous_delivery=read(out.parent/'DELIVERY_MANIFEST.json')
for e in previous_delivery['files']:
    assert sha(out.parent/e['path'])==e['sha256'],'An existing rc5 delivered asset changed: '+e['path']
remote=read(w/'remote-rc2/artifact-verification-result.json');assert remote['remote_artifact_verified'] and remote['head']==head
runs=read(w/'remote-rc2/final-runs.json')['workflow_runs']
assert len(runs)==2 and all(x['head_sha']==head and x['conclusion']=='success' for x in runs)
validation=read(r/'release/next/VALIDATION.json');assert validation['status']=='VERIFIED_CANDIDATE'
audit=read(r/'release/next/CONSISTENCY_RESULT.json');assert audit['status']=='POST_VALIDATION_AUDIT_COMPLETED'
assert (out/'Ising_v0.3.0-rc2_Candidate.bundle').is_file()
assert read(w/'bundle-checkout-result.json')['head']==head

tracked=set(git('ls-files','-z').split('\0'))
copies=set(n for n in tracked if n.startswith(('paper/next/','release/next/')))
copies.update(['README.md','README.zh.md','CLAIMS.md','LIMITATIONS.md','AUTHORSHIP.md',
    'docs/AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md','docs/MATHEMATICAL_AUDIT_v0.3.0-rc2.md',
    'docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md','docs/VERSIONS.md','docs/PROOF_GUIDE.md',
    'release/CURRENT_STATUS.json','provenance/AMPLITUDE_BASELINE.json',
    'provenance/EXTERNAL_PREMISES.md','checks/amplitude_identification/SOURCES.json'])
for name in sorted(copies):
    dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    source=r/name
    if source.suffix=='.md':
        def fix(m):
            label,target=m[1],m[2]
            if re.match(r'^[a-zA-Z]+:',target) or target.startswith('#'):return m[0]
            target,sep,anchor=target.partition('#')
            resolved=posixpath.normpath(posixpath.join(posixpath.dirname(name),target))
            url=posixpath.relpath(resolved,posixpath.dirname(name) or '.') if resolved in copies else 'https://github.com/LeoLam233/ising-bulk-natural-boundary/blob/'+head+'/'+resolved
            return '['+label+']('+url+(sep+anchor if sep else '')+')'
        dest.write_text(re.sub(r'\[([^\]]*)\]\(([^)]+)\)',fix,source.read_text(encoding='utf-8')),encoding='utf-8',newline='\n')
    else:shutil.copyfile(source,dest)
shutil.copyfile(w/'remote-rc2/artifact-verification-result.json',out/'REMOTE_CI_RESULT.json')
shutil.copyfile(w/'bundle-checkout-result.json',out/'BUNDLE_CHECKOUT_RESULT.json')

# Keep post-commit transport/remote evidence separate from the immutable local archive.
extra={}
for folder,prefix in [(w/'logs','logs'),(w/'remote-rc2','remote-acceptance')]:
    for p in folder.rglob('*'):
        if p.is_file() and not p.name.startswith('fetch-primary-sources.'):
            extra[prefix+'/'+p.relative_to(folder).as_posix()]=p
for p in w.glob('*.py'):
    if not p.name.startswith('download_'):extra['drivers/'+p.name]=p
for name in ('bundle-checkout-result.json','observed-operations.json'):
    if (w/name).is_file():extra['final-records/'+name]=w/name
index=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(extra.items())]
with tarfile.open(out/'FINAL_EXECUTION_RECORDS.tar.gz','w:gz',compresslevel=9) as tar:
    for n,p in sorted(extra.items()):tar.add(p,arcname=n,recursive=False)
(out/'FINAL_EXECUTION_INDEX.json').write_text(json.dumps(dict(scope='Later repository, transport, exact-head remote CI and offline-bundle checks; no third-party reading copies or signed-download helpers.',
    sha256=sha(out/'FINAL_EXECUTION_RECORDS.tar.gz'),files=index),indent=2)+'\n',encoding='utf-8',newline='\n')
rows='\n'.join('| ['+x['name']+']('+x['html_url']+') | success |' for x in runs)
report=f'''# Complete-amplitude research — delivered candidate

**The complete-amplitude identification is resolved with a conversion, not an unscaled equality.** On the specified physical exterior germ and selected distinct nonzero-angle family,

`A_full = 4 A_chart = 4 R_N(-theta_*) = -4i R_N(theta_*)`.

The principal-power scalar is preprint (69), journal (70). The factor four is the complete signed chart sum; the phase follows from continuation of the physical interior root. Lower double-contour T_N has amplitude 2 A_chart; full offsite 2T_N and full-site each have 4 A_chart. Physical normalized bulk and susceptibility carry M² and beta_phys M², respectively. The local deviation, coordinate Jacobians and branches are specified in [the mathematical report](docs/AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md).

[Existing draft PR #3](https://github.com/LeoLam233/ising-bulk-natural-boundary/pull/3) is updated to manuscript **v0.1-rc6 / Lean v0.3.0-rc2**. Final commit `{head}`; tree `{tree}`. The research branch and existing PR branch both point to this commit. The mathematical source commit is `dce74bc7ce1106e96b0d754360ac9fbed5f2feea`.

The verified predecessor `dd977048` is preserved in history and in the complete bundle. All 1075 production Lean sources are unchanged. E3 remains absent from canonical compiled types and proof bodies; physical identification retains E1/E2. The new literature-amplitude identity and radial Taylor reconstruction are manuscript-only. Main and frozen release tags are unchanged; no new PR, merge or release publication occurred. Earlier delivered rc5 files were not overwritten.

## Executed acceptance

- Clean complete Lean build: 4838 jobs; 9225 safe project declarations; axiom union propext, Classical.choice, Quot.sound; 18 exact endpoints.
- Seven Lean controls, an additional unused-E3 rejection, 13 manifest cases, 12 prebuild and 13 complete postbuild production cases; fresh official kernel replay exit 0.
- All six historical diagnostics and retained rc5 mathematical checks rerun. New amplitude checks: nine exact symbolic identities, exact p=11 four-center enumeration, three 90-digit full-observable quadratures and branch/phase samples; three supplementary exact phase/coordinate identities.
- Three-pass 47-page PDF, all pages rendered and inspected, 68 labels with all 67 rc5 label numbers retained.
- Mandatory fresh post-validation repository-wide audit, five isolated expected consistency-guard rejections, positive controls before/after and final inventory checks passed. Frozen/provenance guards preserve 211 originals, 17 metadata copies, four rc5 snapshot/reports and 13 immutable predecessor identities.
- Complete offline Git bundle verified and cloned into a fresh checkout; the candidate guard passes on that clean checkout.

Both remote workflows also passed for the exact final commit. The complete downloaded remote artifact matches GitHub's SHA-256; its actual identities, build, axiom/endpoints, controls and fresh replay were checked against the local accepted inputs.

| Remote workflow | Conclusion |
|---|---|
{rows}

[Local validation](release/next/VALIDATION.json) · [Remote artifact verification](REMOTE_CI_RESULT.json) · [Consistency audit](docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md) · [Scoped mathematical audit](docs/MATHEMATICAL_AUDIT_v0.3.0-rc2.md) · [Versions](docs/VERSIONS.md).

## Artifacts and limits

[Manuscript PDF](paper/next/manuscript.pdf) and [standalone TeX](paper/next/manuscript.tex); [complete-history Git bundle](Ising_v0.3.0-rc2_Candidate.bundle); [local execution archive](release/next/evidence/execution-records.tar.gz) and [index](release/next/evidence/INDEX.json); [later execution archive](FINAL_EXECUTION_RECORDS.tar.gz) and [index](FINAL_EXECUTION_INDEX.json); [remote CI artifact ZIP](Ising_v0.3.0-rc2_Remote_CI.zip).

No mathematical obligation remains for the conversion within its stated family. Original Nickel 1999/2000 publisher text remained inaccessible; no original intended convention or original-paper error is attributed. The directly inspected review plus its cited integral fix the observable being compared. Third-party papers and challenge pages are not redistributed.

The function coefficient is a first radial fractional coefficient modulo a finite Taylor polynomial. No new convergent full Puiseux or uniform sectoral expansion, odd-order/degenerate-point result, second kernel, complete Mathlib source rebuild, independent human certification or exhaustive novelty clearance is claimed. Numerical diagnostics do not certify continuous remainders or infinite sums. Failed attempts and unavailable checks remain [separately recorded](release/next/FAILURES.md).
'''
(out/'FINAL_DELIVERY.md').write_text(report,encoding='utf-8',newline='\n')
files=[dict(path=p.relative_to(out).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(out.rglob('*')) if p.is_file()]
(out/'DELIVERY_MANIFEST.json').write_text(json.dumps(dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    head=head,tree=tree,manuscript='v0.1-rc6',lean_candidate='v0.3.0-rc2',
    both_remote_workflows_passed=True,remote_artifact_verified=True,files=files,
    previous_delivered_assets_preserved=len(previous_delivery['files']),
    excludes=['DELIVERY_MANIFEST.json'],markdown_copies='Relative links to omitted files are rewritten to the immutable final GitHub commit; repository originals remain in the bundle.'),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'delivered_files_excluding_manifest':len(files),'head':head,'output_directory':str(out)},indent=2))
