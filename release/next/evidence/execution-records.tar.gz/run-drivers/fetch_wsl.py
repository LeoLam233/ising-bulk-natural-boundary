"""Second source retrieval with the WSL system TLS trust store (no TLS bypass)."""
import datetime, hashlib, json, pathlib, urllib.parse, urllib.request

root = pathlib.Path(__file__).resolve().parent
entries = []
for name, url in [
    ('review-journal-wsl', 'https://www.lptmc.jussieu.fr/files/maillard/PUB2/The_Importance_Ising.pdf'),
    ('nickel-2000-wsl', 'https://iopscience.iop.org/article/10.1088/0305-4470/33/8/313/pdf'),
    ('nickel-1999-wsl', 'https://iopscience.iop.org/article/10.1088/0305-4470/32/21/303/pdf'),
    ('orrick-2001-v1', 'https://arxiv.org/pdf/cond-mat/0103074v1'),
]:
    entry = dict(id=name, url=url, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    try:
        with urllib.request.urlopen(url, timeout=40) as response:
            data = response.read()
            entry.update(http_status=response.status,
                         response_host=urllib.parse.urlparse(response.url).netloc,
                         content_type=response.headers.get('Content-Type'),
                         bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                         is_pdf=data.startswith(b'%PDF-'))
        path = root / (name + ('.pdf' if entry['is_pdf'] else '.html'))
        path.write_bytes(data)
        entry['file'] = path.name
    except Exception as exc:
        entry['error'] = type(exc).__name__ + ': ' + str(exc)
    entries.append(entry)
    print(json.dumps(entry), flush=True)
(root/'source-retrieval-wsl.json').write_text(json.dumps(entries, indent=2)+'\n')
