"""Retrieve public primary sources; retain HTTP failures and content identities.

Downloaded third-party papers are scratch reading copies, not redistribution assets.
"""
import concurrent.futures, datetime, hashlib, json, pathlib, urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
SOURCES = {
    'review-journal': 'https://www.lptmc.jussieu.fr/files/maillard/PUB2/The_Importance_Ising.pdf',
    'review-arxiv-v1': 'https://arxiv.org/pdf/1203.1456v1',
    'boukraa-arxiv-v1': 'https://arxiv.org/pdf/0808.0763v1',
    'nickel-1999-iop': 'https://iopscience.iop.org/article/10.1088/0305-4470/32/21/303/pdf',
    'nickel-2000-iop': 'https://iopscience.iop.org/article/10.1088/0305-4470/33/8/313/pdf',
    'nickel-1999-crossref': 'https://api.crossref.org/works/10.1088/0305-4470/32/21/303',
    'nickel-2000-crossref': 'https://api.crossref.org/works/10.1088/0305-4470/33/8/313',
    'nickel-1999-openalex': 'https://api.openalex.org/works/https://doi.org/10.1088/0305-4470/32/21/303',
    'nickel-2000-openalex': 'https://api.openalex.org/works/https://doi.org/10.1088/0305-4470/33/8/313',
}

def retrieve(item):
    name, url = item
    receipt = {'id': name, 'url': url, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'IsingAmplitudeResearch/1.0'})
        with urllib.request.urlopen(req, timeout=45) as response:
            data = response.read()
            receipt.update(status=response.status, final_url=response.url,
                           content_type=response.headers.get('Content-Type'),
                           bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        suffix = '.pdf' if data.startswith(b'%PDF-') else '.json' if data[:1] == b'{' else '.html'
        (ROOT / (name + suffix)).write_bytes(data)
        receipt['saved_file'] = name + suffix
    except Exception as exc:
        receipt.update(error=type(exc).__name__ + ': ' + str(exc))
    return receipt

if __name__ == '__main__':
    destination = ROOT / 'source-retrieval.json'
    if destination.exists():
        raise SystemExit('Refusing to overwrite source-retrieval.json')
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(retrieve, SOURCES.items()))
    destination.write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    for result in results:
        print(json.dumps(result))
