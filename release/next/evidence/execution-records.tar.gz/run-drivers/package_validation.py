from pathlib import Path
import hashlib,json,shutil,tarfile,datetime

base=Path(__file__).resolve().parents[1];repo=base/'work/repo';logs=base/'work/logs'
linux=base/'work/linux-evidence';out=repo/'release/next/evidence'
out.mkdir(exist_ok=False)
seq=json.loads((logs/'acceptance-02/full/sequence.result.json').read_text())
assert seq['status']=='CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND'
assert json.loads((logs/'acceptance-02/summary.json').read_text())['all_executed_stages_passed']
controls=linux/'control_packet/continuation/results'
manifest=next(p for p in controls.glob('manifest-*/summary.json'))
production=next(p for p in controls.glob('remediation-*/summary.json') if json.loads(p.read_text())['case_count']==13)
lean=next(controls.glob('lean-*/summary.json'))
negative=next((linux/'.local').glob('unused-e3-control-*/result.json'))
assert json.loads(negative.read_text())['passed']
copies={
 'clean-sequence.json':logs/'acceptance-02/full/sequence.result.json',
 'acceptance-summary.json':logs/'acceptance-02/summary.json',
 'manifest-controls.json':manifest,'production-controls-13.json':production,
 'lean-controls-7.json':lean,'unused-E3-control.json':negative,
 'historical-diagnostics.json':repo/'.local/checks-rhk47qxq/REPRODUCTION_RECORD.json',
 'new-mathematical-checks.json':logs/'next-checks-pinned-results.json',
}
for name,source in copies.items():shutil.copyfile(source,out/name)
sources={}
for root,prefix in [(logs,'logs'),(linux,'linux-controls'),
 (repo/'.local/checks-rhk47qxq','historical-diagnostic-run'),
 (repo/'.local/rc5-paper-vriv8e_a','final-paper-build')]:
    for p in root.rglob('*'):
        if p.is_file():sources[prefix+'/'+p.relative_to(root).as_posix()]=p
for p in (base/'work/pdfqa').glob('contact-*.png'):sources['pdf-qa/'+p.name]=p
for name in ['run_logged.py','run_acceptance.py','setup_linux.py','sync_linux.py','prepare_final_linux.py',
             'collect_evidence_linux.py','package_validation.py','pdf_contacts.py']:
    p=base/'work'/name
    if p.is_file():sources['run-drivers/'+name]=p
files=[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
       for name,p in sorted(sources.items())]
archive=out/'execution-records.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for name,p in sorted(sources.items()):tar.add(p,arcname=name,recursive=False)
index={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'archive':archive.name,'bytes':archive.stat().st_size,
       'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
       'scope':'Immutable executed streams/receipts, failed attempts, controls, diagnostics and PDF contact sheets. No compiled project/dependency binary tree. Absolute paths record actual executions, not portable path requirements.',
       'files':files}
(out/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archive_bytes':index['bytes'],'archive_sha256':index['sha256'],'archived_files':len(files),
                  'receipt_files':len(copies)},indent=2))
