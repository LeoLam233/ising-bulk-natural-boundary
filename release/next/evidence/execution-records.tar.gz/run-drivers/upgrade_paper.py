"""Apply the scoped, proved amplitude-conversion addition to the rc5 manuscript."""
import hashlib, pathlib

root = pathlib.Path(__file__).resolve().parents[1]/'repo'
path = root/'paper/next/manuscript.tex'
data = path.read_bytes()
assert hashlib.sha256(data).hexdigest() == '18c5a184b794ee9fa9cc3db1bf42a319c0d08f9fe2101dabc796943cfe706dbf'
s = data.decode('utf-8')
s = s.replace('v0.1-rc5; Lean candidate v0.3.0-rc1', 'v0.1-rc6; Lean candidate v0.3.0-rc2')
s = s.replace('Version 0.1-rc5 (candidate', 'Version 0.1-rc6 (candidate')
s = s.replace('Lean candidate is version 0.3.0-rc1;', 'Lean candidate is version 0.3.0-rc2;')
s = s.replace('obstruction to smooth extension on every boundary arc. The corresponding',
              'obstruction to smooth extension on every boundary arc. It also identifies\n'
              'the complete selected-point amplitude relative to the literature\n'
              'formula, including its four-chart degeneracy and physical branch. The corresponding')
start = s.index('Boukraa et al.\'s equations (5)--(9)')
end = s.index('% END SOURCE', start)
replacement = r'''\paragraph{The same observable in the original literature.}
The low-temperature expansion (45) of \cite{McCoyMaillard2012}
places \(\M^2\) outside the sum of \(\chi^{(N)}\).
Its cited integral source, \cite[(1.10), (3.13), (3.17)--(3.20)]{Orrick2001},
has the full angular torus, the factorial \(1/N!\), and the factor
\((1+Z)/(1-Z)\). At isotropy its anisotropy factor \(\cot\alpha\)
is one; that source's anisotropy symbol is unrelated to our geometric
angle. Thus its \(\widehat\chi^{(N)}\), the review's \(\chi^{(N)}\),
and our \(C_N^{\rm std}\) are the same normalized full-site coefficient.
Equations (4)--(9) of \cite{Boukraa2008} independently give this form:
\[
 C_N^{\rm std}=\frac1{N!}
 \int\prod_{i<N}\frac{\dd\varphi_i}{2\pi}
 \prod_i\frac1{\sinh\gamma_i}\,
 \frac{1+Z}{1-Z}
 \prod_{i<j}\left[
  \frac{\sin((\varphi_i-\varphi_j)/2)}
       {\sinh((\gamma_i+\gamma_j)/2)}
             \right]^2 .
\]
Here \(\sum_i\varphi_i=0\pmod{2\pi}\),
\(\cosh\gamma_i=S-\cos\varphi_i\), and \(z_i=e^{-\gamma_i}\).
The last source's \(w=s/[2(1+s^2)]\) satisfies \(1/(2w)=S\);
its \(x_i\) is our \(z_i\), and its \(y_i=1/\sinh\gamma_i\)
is not our contour coordinate. In particular the source's \(y_i\)
includes its numerator \(2w\). These are literal substitutions,
not a normalization inferred from a numerical match.

\paragraph{The physical branch and four angular charts.}
Continue the positive root \(\gamma_i>0\) from real \(s>1\).
For \(s=r e^{\ii\theta_*}\), \(r>1\),
\(\Im S=(r-r^{-1})\sin\theta_*>0\). The root
\[
 z=(W+\sqrt{W-1}\sqrt{W+1})^{-1},\qquad W=S-\cos\varphi,
\]
with principal square roots is the analytic interior root in this
upper half-plane. It has \(|z|<1\) and \(\Im z<0\), and tends to
\(e^{-\ii\beta}\) at \(\varphi=\pm\alpha\).
Consequently \(\gamma\to\ii\beta\), not \(-\ii\beta\).
Writing \(\gamma=\ii u\), implicit differentiation gives, at
\(\varphi=\alpha\),
\[
 u_\varphi=-\frac{\sin\alpha}{\sin\beta},\qquad
 u_{\varphi\varphi}=-\frac{H_{\alpha\beta}}{\sin^3\beta},\qquad
 s_*u_s=-\frac{2\ii\sin\theta_*}{\sin\beta}.
\]
For \(\varphi_i=\alpha+\tau_i\),
\(\tau_N=-\sum_{i<N}\tau_i\), the linear angular sum vanishes.
With \(a_0=(N^2-1)/2=k+1/2\), \(\nu=k-1/2\),
\(Q=2N\sin\theta_*/\sin\beta\), and
\(d=H_{\alpha\beta}/(2\sin^3\beta)>0\), the denominator begins as
\[
 1-Z=Q\eps-\ii d\sum_i\tau_i^2
       +O(\eps^2+\eps|\tau|+|\tau|^3).
\]
Each one-body coefficient is \(-\ii/\sin\beta\), and each
squared pair contributes \(-1/(4\sin^2\beta)\).
For \(N=2m\) their total phase is
\((-\ii)^N(-1)^{N(N-1)/2}=(-1)^{2m^2}=1\).
The numerator \(1+Z\) tends to two. Thus the chart prefactor is
\[
 p_0=\frac{2\,2^{-N(N-1)}}{N!(2\pi)^{N-1}\sin^{N^2}\beta}
     =2\pi K_\beta.
\]
This is the same constrained coordinate measure and normal form
as after our mean residue. Its \(k\)-th complex derivative
therefore has coefficient \(L_\beta\), with the finite-jet and
remainder control already used in Section~\ref{sec:first}.
The factor \(\sqrt N\) converting hyperplane area to this coordinate
measure is already in \(\mathscr C_N\); it must not be inserted again.

The selected point has exactly the two distinct nonzero cosine
values from Theorem~\ref{thm:prime}. In this angular representation
they give four signed centers \(+\alpha,-\alpha,+\beta,-\beta\).
All satisfy the periodic constraint because \(N\alpha,N\beta\in2\pi\Z\).
Angle reversal preserves the real measure and squared Vandermonde;
the \(\alpha/\beta\) exchange preserves \eqref{eq:amplitudeclosed}.
Thus all four coefficients agree. Particle permutations fix each
all-equal center, so no further \(N!\) is attached to this count.
Completeness is also forced by the already proved identity
\(C_N^{\rm std}=f_{00}^{(N)}+2T_N\): the two offsite charts give
\(2L_\beta\), and the onsite term has bounded fixed derivatives.
There is no unestimated same-order contribution in this comparison.

\begin{proposition}[Complete-amplitude conversion]\label{prop:amplitudecomparison}
Fix the selected prime family and its first even order \(N=2p\).
In the review's index convention take \(j=2a\), \(l=2b\), so that
\(\phi^{(j)}=\alpha\), \(\phi^{(l)}=\beta\).
For \(\vartheta=\pm\theta_*\), define the expressly evaluated
printed scalar
\[
 R_N(\vartheta)=
 \frac{(N\ii\sin\vartheta)^\nu P_N}
 {H_{\alpha\beta}^{a_0}\pi^{(N-3)/2}\sqrt N\,\Gamma(a_0)},
\]
using the principal power in the numerator and the positive real
power of \(H_{\alpha\beta}\). This is (69) in the arXiv version
of \cite{McCoyMaillard2012}, or (70) on p.~801 of the journal
version; its angle relation is respectively (70) or (71).
On the physical low-temperature exterior germ put
\(\delta=1-s_*/s=\eps/(1+\eps)>0\).
Modulo a radial Taylor polynomial of degree at most \(k-1\), the
coefficient of \(\delta^\nu\) is
\[
 \begin{array}{c|c}
  \text{observable}&\text{coefficient}\\ \hline
  \text{one chart}&A_{\rm chart}=R_N(-\theta_*)=-\ii R_N(\theta_*)\\
  T_N&2A_{\rm chart}\\
  C_N^{\rm std}=\chi^{(N)}\text{ of the review}&4A_{\rm chart}\\
  \text{physical normalized bulk }\mathcal X&4\M^2(s_*)A_{\rm chart}\\
  \text{physical }\chi&4\beta_{\rm phys}(s_*)\M^2(s_*)A_{\rm chart}
 \end{array}
\]
The last two rows use the physical identification and the first-order
and tail results of Theorem~\ref{thm:conditional}. The unnormalized
offsite lattice coefficient is \(2T_N\), not \(T_N\); its singular
coefficient equals that of \(C_N^{\rm std}\).
The corresponding \(k\)-th complex derivative coefficients are
\(L_\beta,2L_\beta,4L_\beta,4\M^2(s_*)L_\beta\), and
\(4\beta_{\rm phys}(s_*)\M^2(s_*)L_\beta\).
\end{proposition}
\begin{proof}
Taking \(k\) radial derivatives multiplies a complex derivative by
\(s_*^k\). If \(f^{(k)}(\eps)=B\eps^{-1/2}+o(\eps^{-1/2})\),
its integrability gives finite limits for all lower derivatives.
The integral Taylor remainder is
\[
 \frac1{(k-1)!}\int_0^\eps(\eps-t)^{k-1}f^{(k)}(t)\dd t
 =\frac{B\sqrt\pi}{\Gamma(k+1/2)}\eps^{k-1/2}
       +o(\eps^{k-1/2}).
\]
The same estimate with the error bounded by
\(\sup_{0<t<\eps}o(1)\,t^{-1/2}\) justifies the last little-o.
Changing to \(\delta=\eps/(1+\eps)\) changes the Taylor polynomial
but preserves this first fractional coefficient. In particular
\[
 A_{\rm chart}=s_*^kL_\beta\frac{\sqrt\pi}{\Gamma(a_0)}.
\]
Equation~\eqref{eq:amplitudeclosed} gives its positive magnitude
factor and phase \((-1)^ke^{\ii\pi a_0/2}\).
For even \(N\), \(k=2(N/2)^2-1\) is odd, hence this phase equals
\(e^{-\ii\pi\nu/2}\). The latter is exactly the principal power
phase at \(\vartheta=-\theta_*\); at \(+\theta_*\) the ratio is
\(-\ii\). The geometric denominator and every factorial factor
are identical, proving the scalar identities.
The two/four chart counts, bounded onsite derivative and bulk
product rule above give the remaining rows. The Taylor integration
also applies to the full bulk because its already proved \(k\)-th
derivative has precisely the indicated leading term.

As a separate check of the local phase, the radial normal-form
integral has integrand \(r^{2k}/(q+b r^2)\), with \(q=Q\eps\)
and \(b=-\ii d\). Polynomial division leaves
\[
 \int_0^\eta\frac{r^{2k}}{q+b r^2}\dd r
 =\text{polynomial in }q+
 \frac{(-q)^k}{b^k\sqrt{qb}}
             \arctan\!\left(\eta\sqrt{b/q}\right).
\]
Continue \(b\) from the positive real axis to \(-\ii d\), with
\(q>0\). The last factor tends to \(\pi/2\); its noninteger term
is \((\pi/2)(-1)^kq^{k-1/2}b^{-k-1/2}\).
Multiplying by \(p_0\mathscr C_N\) gives the same coefficient.
This check concerns the normal form; the original finite-jet proof,
not the polynomial calculation alone, controls its replacement error.
\end{proof}

The physical prefactors have fixed branches too. On this quadrant,
the continuation with \(\M^2\to1\) at infinity has
\[
 \M^2(s_*)=(2\sin2\theta_*)^{1/4}
             e^{\ii(\pi/8-\theta_*/2)},\qquad
 \beta_{\rm phys}(s_*)=\frac{\operatorname{arsinh}(s_*)}{2J},
\]
where \(\operatorname{arsinh}\) is continued from positive real
\(s>1\) through the right half-plane. These factors are analytic
and nonzero locally. They are absent from the review's normalized
\(\chi^{(N)}\). For another local coordinate
\(x=\lambda\delta+O(\delta^2)\), the coefficient instead acquires
\(\lambda^{-\nu}\) with the continued power branch; here
\(\lambda=1\) for the two stated radial variables.

Thus the printed scalar is a single-chart value in these conventions.
Reading that scalar as the complete \(\chi^{(N)}\) coefficient without
the degeneracy sum misses a factor four. This conclusion is independent
of the review's unspecified angle sign: all branches of the displayed
half-integer powers have the same magnitude, whereas the complete
coefficient has four times that magnitude. The review's cosine relation
alone does not fix the physical phase; the integral continuation above
does. We do not attribute an intended single-pinch convention to an
unexamined derivation, or import any conclusion about degenerate angles,
the four-particle endpoint, or nonphysical continuation sheets.
Neither the printed formula nor its interpretation is a premise of
our nonvanishing or natural-boundary argument.

'''
s = s[:start] + replacement + s[end:]
s = s.replace('\\subsection*{Rc5 internal regularity and formal scope}\nThe current manuscript is 0.1-rc5, paired with Lean candidate 0.3.0-rc1.',
              '\\subsection*{Rc5 internal regularity and formal scope}\nVersion 0.1-rc5 was paired with Lean candidate 0.3.0-rc1.')
anchor = '\nExact build, transitive-dependency, axiom, kernel-replay, and PDF receipts\n'
assert anchor in s
s = s.replace(anchor, r'''
\subsection*{Rc6 complete-amplitude comparison and formal scope}
The current manuscript is 0.1-rc6, paired with Lean candidate 0.3.0-rc2.
Proposition~\ref{prop:amplitudecomparison} identifies the full-site
observable from the review's cited integral, fixes the exterior branch,
and proves the four-chart conversion of its printed scalar. It also
distinguishes the lower double-contour coefficient from the full offsite
lattice coefficient and includes both physical prefactors. The new
conversion and radial Taylor reconstruction are manuscript results;
the factorial and literature-amplitude identities are not new Lean exports.
The production Lean theorem sources and their mathematical dependency
chain are unchanged from the verified rc5/0.3.0-rc1 candidate. Updated
source correspondence and verification identities belong to this revision;
the preserved commit records the earlier candidate without reassigning its
receipts to new bytes.
''' + anchor, 1)
s = s.replace('\\newblock \\href{https://arxiv.org/abs/1203.1456}{arXiv:1203.1456}.\nPhysical definitions and amplitude conventions; the printed amplitude\nis not used as a premise for the internal coefficient.',
              '\\newblock \\href{https://arxiv.org/abs/1203.1456}{arXiv:1203.1456};\n'
              '\\href{https://www.lptmc.jussieu.fr/files/maillard/PUB2/The_Importance_Ising.pdf}{journal PDF}.\n'
              'The amplitude formula is preprint (69), journal (70).\n'
              'It is compared with the derived coefficient, not imported as a premise.')
path.write_text(s, encoding='utf-8', newline='\n')
print('UPDATED', path, 'sha256', hashlib.sha256(path.read_bytes()).hexdigest())
