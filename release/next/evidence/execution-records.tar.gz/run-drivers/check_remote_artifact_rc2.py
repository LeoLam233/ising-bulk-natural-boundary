"""Verify downloaded remote CI evidence against this candidate's accepted inputs."""
from pathlib import Path
import hashlib, json, re, zipfile

w=Path(__file__).resolve().parent;r=w.parent/'repo';out=w.parents[1]/'outputs/amplitude-rc6'
remote=w/'remote-rc2'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
ids=read(r/'lean/ci/accepted_identity.json')
runs=read(remote/'final-runs.json')['workflow_runs']
assert len(runs)==2 and all(x['status']=='completed' and x['conclusion']=='success' for x in runs)
heads={x['head_sha'] for x in runs};assert len(heads)==1
head=heads.pop()
meta=read(remote/'artifacts.json')
artifacts=meta.get('artifacts',meta.get('structuredContent',{}).get('artifacts'))
assert len(artifacts)==1
artifact=artifacts[0]
archive=out/'Ising_v0.3.0-rc2_Remote_CI.zip'
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert artifact['digest']=='sha256:'+digest and artifact['workflow_run']['head_sha']==head
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts and '\\' not in n for n in names)
    def entry(suffix):
        hits=[n for n in names if n.endswith(suffix)]
        assert len(hits)==1,(suffix,hits)
        return hits[0]
    def document(suffix):return json.loads(z.read(entry(suffix)))
    seq=document('/sequence.result.json');started=document('/sequence.started.json')
    assert seq['status']=='CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND'
    assert all(seq[k]==v for k,v in ids.items())
    assert seq['audited_safe_declaration_count']==9225 and seq['endpoint_count']==18
    assert seq['production_module_count']==1074 and seq['fresh_kernel_replay_exit']==0
    assert set(seq['axiom_union'])=={'propext','Classical.choice','Quot.sound'}
    assert all(s['exit_code']==0 and not s['interrupted'] for s in seq['stages'])
    assert started['clean_project_outputs_absent'] and started['threads']==2
    before=document('/preflight.before.json');after=document('/preflight.after.json')
    assert all(before[k]==after[k]==v for k,v in ids.items())
    assert re.findall(r'AUDIT PASSED:\s*(\d+) kernel-safe project declarations',z.read(entry('/02_axiom_audit.stdout.log')).decode())==['9225']
    assert re.findall(r'ENDPOINT_CHECK_PASSED:\s*(\d+)',z.read(entry('/03_endpoints.stdout.log')).decode())==['18']
    assert 'Build completed successfully (4838 jobs).' in z.read(entry('/01_clean_project_build.stdout.log')).decode()
    assert 'replaying IsingBulk with --fresh' in z.read(entry('/04_kernel_replay.stdout.log')).decode()
    negative,_=json.JSONDecoder().raw_decode(z.read(entry('/03c_dependency_negative_control.stdout.log')).decode().lstrip())
    assert negative['passed'] and negative['context_unchanged'] and negative['context']==ids
    summaries=[(n,json.loads(z.read(n))) for n in names if n.endswith('/summary.json')]
    manifests=[s for n,s in summaries if '/manifest-' in n]
    leans=[s for n,s in summaries if '/lean-' in n]
    productions=[s for n,s in summaries if '/remediation-' in n]
    assert len(manifests)==1 and manifests[0]['all_controls_pass'] and manifests[0]['case_count']==13
    assert len(leans)==1 and leans[0]['all_controls_pass'] and leans[0]['case_count']==7
    assert leans[0]['context']==ids and leans[0]['context_unchanged']
    assert sorted(s['case_count'] for s in productions)==[12,13] and all(s['all_controls_pass'] for s in productions)
    for s in productions:assert s['expected_id']==s['source_payload_id']==ids['PROOF_CRITICAL_PAYLOAD_ID']
jobs_meta=read(remote/'jobs.json')
jobs=jobs_meta.get('jobs',jobs_meta.get('structuredContent',{}).get('jobs'))
assert jobs and all(j['conclusion']=='success' and all(s['status']=='completed' and s['conclusion']=='success' for s in j['steps']) for j in jobs)
full=next(x for x in runs if x['path']=='.github/workflows/lean-full-acceptance.yml')
result=dict(remote_artifact_verified=True,head=head,run_id=full['id'],artifact_id=artifact['id'],
    artifact_sha256=digest,artifact_bytes=archive.stat().st_size,zip_entries=len(names),all_zip_crc_checks_passed=True,
    identities=ids,root_build_jobs=4838,safe_project_declarations=9225,endpoints=18,manifest_controls=13,
    production_verifier_prebuild_cases=12,production_verifier_complete_cases=13,ordinary_lean_controls=7,
    unused_E3_control_passed=True,fresh_kernel_replay_exit=0,candidate_consistency_step='completed/success',
    finished_utc=seq['finished_utc'],
    stages=[dict(stage=s['stage'],seconds=s['elapsed_seconds'],exit_code=s['exit_code']) for s in seq['stages']],
    scope='Downloaded exact-head artifact, checked CRC/content identities and actual clean sequence/controls/axioms/endpoints/replay; all job steps including candidate consistency passed. Same kernel and pinned dependency-cache/source trust limits apply.')
(remote/'artifact-verification-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result,indent=2))
