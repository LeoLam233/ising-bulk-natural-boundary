from pathlib import Path
import json
w=Path(__file__).resolve().parent
r=w.parent/'repo'
p=json.loads((w/'preflight-rc2-final.json').read_text())
keys=('PROOF_CRITICAL_PAYLOAD_ID','VERIFICATION_INPUT_ID','RUNTIME_ID')
identities={k:p[k] for k in keys}
def put(name,obj):(r/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
put('lean/ci/accepted_identity.json',identities)
put('lean/ci/payload.json',dict(candidate_version='v0.3.0-rc2',manuscript_version='v0.1-rc6',
    PROOF_CRITICAL_PAYLOAD_ID=p[keys[0]],proof_inputs=p['proof_inputs'],
    evidence='Fresh exact-input execution status belongs to release/next/VALIDATION.json. The verified predecessor is dd977048; no old receipt is reassigned.'))
put('release/CURRENT_STATUS.json',dict(manuscript_version='v0.1-rc6',lean_candidate='v0.3.0-rc2',
    published_release=False,development_branch='research/next-internal-regularity-20261017',
    research_branch='research/amplitude-identification-20261017',
    existing_pr='https://github.com/LeoLam233/ising-bulk-natural-boundary/pull/3',
    manuscript_source_commit='dce74bc7ce1106e96b0d754360ac9fbed5f2feea',
    verified_predecessor='dd977048c2380e775d83b97ae1fba354c04c349a',
    canonical_normalized_external_premises=[],physical_external_premises=['E1','E2'],
    E3_canonical_dependency=False,identities=identities,acceptance_status='FRESH_GATE_IN_PROGRESS',
    validation='next/VALIDATION.json',version_ledger='../docs/VERSIONS.md',
    independent_human_expert_validation=False,peer_reviewed=False))
put('release/next/VALIDATION.json',dict(manuscript='v0.1-rc6',lean_candidate='v0.3.0-rc2',
    status='FRESH_VALIDATION_IN_PROGRESS',identities=identities,
    preserved_previous_verified_commit='dd977048c2380e775d83b97ae1fba354c04c349a',
    note='This in-progress record does not assign the previous candidate receipts to rc6. Final executed results replace this record after all checks.'))
print(json.dumps(identities,indent=2))
