"""Reconcile current-facing documentation without editing versioned old reports."""
from pathlib import Path

r=Path(__file__).resolve().parents[1]/'repo'
base='dd977048c2380e775d83b97ae1fba354c04c349a'
oldurl='https://github.com/LeoLam233/ising-bulk-natural-boundary/tree/'+base
report='docs/AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md'
def put(name,text):(r/name).write_text(text.strip()+'\n',encoding='utf-8',newline='\n')
def current(name):
    return (r/name).read_text(encoding='utf-8').replace('v0.1-rc5','v0.1-rc6').replace('v0.3.0-rc1','v0.3.0-rc2')

name='README.md';s=current(name)
s=s.replace('docs/UPGRADE_v0.3.0-rc2.md',report)
s=s.replace('docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md','docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md')
s=s.replace('- Appendix B evaluates the existing singular coefficient through factorials. Appendix F compares specified single-chart expressions with McCoy–Maillard (69), keeping power branches, phases and chart multiplicities explicit.',
'''- Proposition F.1 resolves the complete-amplitude comparison: on the selected physical exterior germ, `A_full=4R_N(-theta_*)=-4i R_N(theta_*)`. The printed scalar is one chart; the complete full-site coefficient has four equal signed contributions. Observable definitions, local variables, power branches and physical prefactors are derived. The formula is arXiv (69), journal (70).''')
s=s.replace('## Changes','''The verified rc5 / Lean v0.3.0-rc1 candidate remains at [`dd977048`]('''+oldurl+'''). This revision adds the normalization result below and preserves its production Lean sources byte for byte. New manuscript, source correspondence and acceptance receipts have distinct identities.

## Changes''',1)
s=s.replace('python checks/next_version/run_checks.py --output .local/next-checks.json',
'''python checks/next_version/run_checks.py --output .local/next-checks.json
python checks/amplitude_identification/check_amplitude.py --output .local/amplitude-checks.json''')
s=s.replace('The factorial evaluation and quantitative finite-prime covering remain analytic manuscript results.',
            'The factorial evaluation, complete-amplitude conversion and quantitative finite-prime covering remain analytic manuscript results.')
put(name,s)

name='README.zh.md';s=current(name).replace('docs/UPGRADE_v0.3.0-rc2.md',report)
old='只在明确约定下比较文献公式，不擅自指定原文未说明的幂分支。'
new='新命题 F.1 从实际全格点积分和物理延拓分支证明完整系数为 `4R_N(-theta_*)=-4i R_N(theta_*)`。文献右端标量对应单图，完整系数包含四个同相位贡献；同时区分 `T_N`、完整离原点系数 `2T_N`、全格点系数与两个物理前因子。该公式在 arXiv 版为 (69)，期刊版为 (70)。'
assert old in s;s=s.replace(old,new)
s=s.replace('阶乘公式和定量素数覆盖仍属于论文中的解析推导。',
            '阶乘公式、完整振幅转换与定量素数覆盖仍属于论文中的解析推导，并非新的 Lean 导出定理。')
s+='\n已验证的 rc5 / Lean v0.3.0-rc1 候选版完整保留在 [`dd977048`]('+oldurl+')；原生产 Lean 源文件逐字节不变。本修订使用新的论文版本、源码对应身份与执行回执，只更新现有 PR #3，不新建 PR 或合并 main。\n'
put(name,s)

name='CLAIMS.md';s=current(name)
old='The factorial expression evaluates the same single-chart coefficient with the original continuation. Complete offsite and full-site coefficients have multiplicities two and four. McCoy–Maillard (69) matches the specified single-chart expression at inverse angle with the stated principal power; no claim is made that the source explicitly selects that branch or includes the full chart sum in its printed amplitude.'
new='''The factorial expression evaluates the same single-chart coefficient. Proposition F.1 identifies the review's normalized full-site observable through its cited integral and proves `A_full=4A_chart=4R_N(-theta_*)=-4iR_N(theta_*)` on the specified physical exterior germ, with `delta=1-s_*/s`. The lower double-contour `T_N` has amplitude `2A_chart`; the complete offsite normalized particle coefficient is `2T_N`, with amplitude `4A_chart`, equal to full-site. Physical X and chi multiply by M²(s_*) and by beta_phys(s_*)M²(s_*), respectively. Changing angle sign or half-integer power branch cannot supply the missing magnitude factor four. No intended convention is attributed to an unread original derivation.'''
assert old in s;s=s.replace(old,new)
s=s.replace('The factorial evaluation, finite-prime covering and full quantitative physical arc statement are manuscript-only.',
            'The factorial evaluation, complete-amplitude conversion/radial Taylor reconstruction, finite-prime covering and full quantitative physical arc statement are manuscript-only.')
put(name,s)

name='LIMITATIONS.md';s=(r/name).read_text(encoding='utf-8')
s=s.replace('5. The factorial evaluation and finite-prime geometry are analytic manuscript results',
            '5. The factorial evaluation, complete-amplitude conversion/radial Taylor reconstruction and finite-prime geometry are analytic manuscript results')
start=s.index('6. McCoy');end=s.index('\n7.',start)
s=s[:start]+'''6. The inspected McCoy–Maillard scalar is converted exactly to the selected-family complete amplitude in Proposition F.1. Nickel's original 1999/2000 publisher text remained inaccessible; no original intended convention or original-paper error is attributed. This limits historical attribution, not the proved conversion. Degenerate endpoints, odd orders and nonphysical sheets are outside its scope.''' +s[end:]
s=s.replace('Source-convention questions and manuscript-only scope are distinguished from completed results in the [mathematical report](docs/UPGRADE_v0.3.0-rc1.md).',
            'Source-access limits and manuscript-only scope are distinguished from completed results in the [amplitude report]('+report+').')
put(name,s)

name='AUTHORSHIP.md';put(name,current(name))
name='CITATION.cff';s=current(name).replace('version: "0.1-rc5"','version: "0.1-rc6"')
s=s.replace('Exact validation is recorded separately.',
            'Proposition F.1 derives the complete-amplitude conversion on the physical exterior germ; this literature identity is manuscript-only. Exact validation is recorded separately.')
put(name,s)

name='paper/README.md';s=current(name)
s=s.replace('All 65 previous label numbers remain; equation (B.1) and Corollary 9.4 are added.',
            'All 67 verified rc5 label numbers remain; Proposition F.1 is added. It proves the complete-amplitude conversion, with arXiv/journal equation numbering distinguished.')
s+='\nThe verified rc5 manuscript and matching Lean v0.3.0-rc1 records remain at [`dd977048`]('+oldurl+'). Their PDF and source identities are preserved in [the amplitude baseline](../provenance/AMPLITUDE_BASELINE.json). The old versioned reports are read in that immutable tree.\n'
put(name,s)

name='docs/PROOF_GUIDE.md';s=current(name)
s=s.replace('All 65 previous mathematical label numbers remain unchanged.',
            'All 67 verified rc5 mathematical label numbers remain unchanged; Proposition F.1 is added.')
s=s.replace('| Closed amplitude | Appendix B (B.1), Appendix F | Factorial evaluation manuscript-only; existing formal nonvanishing retained. |',
            '| Complete amplitude | Appendix B (B.1), Proposition F.1 | Full-site observable fixed by the cited integral; four-chart conversion and radial Taylor reconstruction manuscript-only; existing formal nonvanishing retained. |')
old='For the amplitude, distinguish `L_beta` (one chart\'s kth complex derivative) from `A_chart` (its radial singular-power coefficient). Offsite/full-site totals have multiplicities two/four. Inverse angle and principal power in the review comparison are specified, not inferred from its cosine equation.'
new='For the amplitude, start with the review\'s (45) and its cited angular integral; this fixes C_N^std. Read the root continuation in Im S>0 before evaluating any complex power. Proposition F.1 converts the kth derivative asymptotic to a radial power modulo a finite Taylor polynomial and counts four signed angular centers. The lower double-contour T_N has two charts, whereas the full offsite coefficient is 2T_N. The complete coefficient is 4R_N(-theta_*)=-4iR_N(theta_*). The formula is arXiv (69), journal (70); the review\'s printed (64) has a sign inconsistent with its following roots. The derivation and physical-prefactor branches, not that sign or the cosine relation alone, fix the result.'
assert old in s;s=s.replace(old,new)
s=s.replace('(UPGRADE_v0.3.0-rc2.md)','(AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md)')
put(name,s)

name='docs/VERSIONS.md';s=(r/name).read_text(encoding='utf-8')
start=s.index('| Manuscript v0.1-rc5 |');end=s.index('\n\nThe source commit',start)
s=s[:start]+'''| Verified manuscript v0.1-rc5 / Lean v0.3.0-rc1 | Immutable predecessor [`dd977048`]('''+oldurl+'''); manuscript source commit `a79c2f5701111b5234bbc0ff8481e75aec8c21d0` | Verified earlier candidate; its source/PDF, full local/remote acceptance receipts and original unresolved-comparison wording retain that version identity. [Preservation hashes](../provenance/AMPLITUDE_BASELINE.json). |
| Manuscript v0.1-rc6 | `paper/next/manuscript.tex` and matching PDF/index/BUILD.json; source commit `dce74bc7ce1106e96b0d754360ac9fbed5f2feea` | Current analytic candidate. All 67 rc5 label numbers retained; Proposition F.1 proves complete-amplitude conversion. |
| Lean v0.3.0-rc2 | Current sources, `lean/SOURCE.json`, `ci/accepted_identity.json` and `release/next/VALIDATION.json` | Current candidate; production Lean sources unchanged from dd977048. New source/configuration/verification identities and freshly executed receipts. Canonical E3 absent; physical E1/E2 retained. No release tag or main merge. |''' +s[end:]
s=s.replace('the new snapshot is `manuscript-rc5.tex`.',
            'the rc5 snapshot `manuscript-rc5.tex` is retained, and the current snapshot is `manuscript-rc6.tex`.')
s+='''\nThe versioned rc1 reports `UPGRADE_v0.3.0-rc1.md`, `MATHEMATICAL_AUDIT_v0.3.0-rc1.md` and `CONSISTENCY_AUDIT_v0.3.0-rc1.md` remain byte-identical. Their relative artifact links and words such as “current” describe the dd977048 tree; use the immutable predecessor link above to read them with their original assets. They do not describe rc6. The current [amplitude report](AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md), [mathematical audit](MATHEMATICAL_AUDIT_v0.3.0-rc2.md) and [consistency audit](CONSISTENCY_AUDIT_v0.3.0-rc2.md) distinguish the revisions. No materially different current PDF is presented as rc5.\n'''
put(name,s)

name='provenance/EXTERNAL_PREMISES.md';s=current(name)
start=s.index('| X2 |');end=s.index('\n',start)
s=s[:start]+'''| X2 | [McCoy–Maillard 2012 journal](https://www.lptmc.jussieu.fr/files/maillard/PUB2/The_Importance_Ising.pdf), (45), (68), (70)–(71); [arXiv v1](https://arxiv.org/pdf/1203.1456v1), amplitude (69) | Compared observable and printed scalar. Proposition F.1 derives its complete selected-family conversion and exterior branch; the printed amplitude is not a proof premise. |
| X3 | [Orrick–Nickel–Guttmann–Perk 2001](https://arxiv.org/pdf/cond-mat/0103074v1), (1.10), (3.13), (3.17)–(3.24) | The review's cited full-site integral fixes its normalization; no arbitrary factor or new canonical premise is introduced. |''' +s[end:]
s+='\nThe amplitude study directly inspected the journal and arXiv review plus the two cited integral sources. Original Nickel 1999/2000 text remained unavailable behind the publisher access challenge. Its intended convention is not attributed. [Source identities/access record](../checks/amplitude_identification/SOURCES.json) and [proved conversion](../'+report+') delimit that historical access limit.\n'
put(name,s)

name='checks/README.md';s=(r/name).read_text(encoding='utf-8')
s+='''\n\n## v0.3.0-rc2 amplitude conversion

Run `python checks/amplitude_identification/check_amplitude.py --output .local/amplitude-checks.json`.
The script checks nine exact symbolic identities, an exact p=11 cyclotomic four-center enumeration, three 90-digit two-particle full-observable quadratures against the published elliptic representation, and specified phase/root samples. These corroborate the analytic derivation in Proposition F.1; they are not continuous asymptotic or all-N certificates. The [source index](amplitude_identification/SOURCES.json) records four inspected primary PDFs and the original Nickel access failures. No third-party PDF is redistributed.
'''
put(name,s)
print('Current-facing documents updated; original rc1 reports and frozen assets were not edited.')
