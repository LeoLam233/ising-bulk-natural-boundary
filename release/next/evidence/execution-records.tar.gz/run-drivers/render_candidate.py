import hashlib, json, pathlib, subprocess
from pypdf import PdfReader
from PIL import Image, ImageDraw

work=pathlib.Path(__file__).resolve().parent
repo=work.parent/'repo'
pdf=repo/'paper/next/manuscript.pdf'
dest=work/'pdfqa-rc6'
dest.mkdir(exist_ok=False)
poppler=pathlib.Path(r'C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe')
argv=[str(poppler),'-png','-scale-to','650',str(pdf),str(dest/'page')]
subprocess.run(argv,check=True)
pages=sorted(dest.glob('page-*.png'))
reader=PdfReader(pdf)
assert len(pages)==len(reader.pages)
hits={}
for i,p in enumerate(reader.pages):
    compact=''.join(p.extract_text().split())
    for key in ('Complete-amplitudeconversion','Thephysicalbranchandfourangularcharts','Rc6complete-amplitudecomparison'):
        if key in compact:hits[key]=i+1
for group in range((len(pages)+8)//9):
    sheet=Image.new('RGB',(1530,2040),'#d8d8d8')
    draw=ImageDraw.Draw(sheet)
    for j,p in enumerate(pages[group*9:group*9+9]):
        im=Image.open(p).convert('RGB');im.thumbnail((490,650))
        xx=(j%3)*510+(510-im.width)//2;yy=(j//3)*680+22
        sheet.paste(im,(xx,yy));draw.text((xx,yy-17),p.stem,fill='black')
    sheet.save(dest/f'contact-{group+1}.png')
record=dict(pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),pages=len(pages),
            argv=argv,paragraph_page_hits=hits,
            contact_sheet_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.glob('contact-*.png'))},
            status='RENDERED_AWAITING_VISUAL_REVIEW')
(dest/'render-inventory.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
