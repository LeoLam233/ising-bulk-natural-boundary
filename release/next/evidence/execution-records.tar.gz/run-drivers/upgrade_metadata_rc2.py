"""Bind rc6 to an unchanged Lean production tree and fresh verification inputs."""
import csv, hashlib, json, pathlib, shutil, subprocess

repo=pathlib.Path(__file__).resolve().parents[1]/'repo'
math='dce74bc7ce1106e96b0d754360ac9fbed5f2feea'
base='dd977048c2380e775d83b97ae1fba354c04c349a'
def git(*args):return subprocess.check_output(['git','-c','safe.directory=*',*args],cwd=repo).decode().strip()
assert git('rev-parse','HEAD')==math
def put(name,text):(repo/name).write_text(text.strip()+'\n',encoding='utf-8',newline='\n')
def read(name):return json.loads((repo/name).read_text(encoding='utf-8'))
def dump(name,data):put(name,json.dumps(data,indent=2))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

old=json.loads(git('show',base+':lean/ci/payload.json'))['proof_inputs']['files']
production={name:value for name,value in old.items() if name.endswith('.lean')}
assert len(production)==1075
assert all(sha(repo/'lean'/name)==value for name,value in production.items())

paper=repo/'paper/next/manuscript.tex'
blob=git('rev-parse',math+':paper/next/manuscript.tex')
shutil.copyfile(paper,repo/'lean/source_snapshot/manuscript-rc6.tex')
source=read('lean/SOURCE.json')
source.update(release='v0.1-rc6',lean_candidate='v0.3.0-rc2',repository_snapshot_commit=math,
              expected_tree_sha=git('rev-parse',math+'^{tree}'),
              manuscript_raw_url='https://raw.githubusercontent.com/LeoLam233/ising-bulk-natural-boundary/'+math+'/paper/next/manuscript.tex',
              local_copy='source_snapshot/manuscript-rc6.tex',expected_git_blob=blob,computed_git_blob=blob,
              sha256=sha(paper),
              verification='Byte-identical committed rc6 manuscript snapshot. All 67 rc5 label numbers remain; Proposition F.1 is added and is manuscript-only.',
              previous_verified_candidate=base,previous_manuscript_snapshot='source_snapshot/manuscript-rc5.tex',
              production_Lean_sources='Byte-identical to the verified previous candidate; no new factorial or literature-amplitude Lean export.')
dump('lean/SOURCE.json',source)
p=repo/'lean/lakefile.toml'
s=p.read_text();assert 'version = "0.3.0-rc1"' in s
put('lean/lakefile.toml',s.replace('version = "0.3.0-rc1"','version = "0.3.0-rc2"'))
freeze=read('lean/TOOLCHAIN_FREEZE.json')
freeze['reason']='v0.3.0-rc2 candidate configuration and rc6 source correspondence. Production Lean proofs, compiler and all nine dependency revisions are unchanged from dd977048. Fresh execution status is separate in release/next/VALIDATION.json.'
for row in freeze['files']:row['sha256']=sha(repo/'lean'/row['path'])
dump('lean/TOOLCHAIN_FREEZE.json',freeze)
contract=read('lean/tools/continuation/endpoint_contract.json')
contract['manuscript_git_blob']=blob
contract['frozen_config_sha256']={r['path']:r['sha256'] for r in freeze['files']}
assert len(contract['endpoints'])==18
dump('lean/tools/continuation/endpoint_contract.json',contract)

p=repo/'lean/CLAIM_LEDGER.tsv'
with p.open(encoding='utf-8',newline='') as f:
    rr=csv.DictReader(f,delimiter='\t');fields=rr.fieldnames;rows=list(rr)
for row in rows:
    row['source_commit']=math
    if row['source_label']=='eq:amplitudeclosed':
        row['statement_equivalence']='The same factorial evaluation of the single-chart coefficient. Proposition F.1 now derives the complete full-site conversion to the printed scalar on the specified exterior branch; both calculations are manuscript-only.'
new=dict.fromkeys(fields,'')
new.update(source_label='prop:amplitudecomparison',source_commit=math,status='MANUSCRIPT_ONLY',
           statement_equivalence='At the selected first even order, the inspected literature full-site coefficient is f00^(N)+2T_N and has original-function amplitude 4R_N(-theta_*)=-4iR_N(theta_*), with stated principal powers, radial variable and physical continuation. Includes the offsite/full-site/physical conversion table and radial Taylor reconstruction.',
           external_inputs='The printed amplitude is not a proof premise. Literature definitions identify the compared observable; E1/E2 enter the physical bulk identification only.',
           dependencies='Existing first derivative asymptotic and remainder bounds, internal onsite bound, exact full-site identity, Hermite evaluation (B.1), angular normal form and elementary integral Taylor remainder.',
           build_receipt='../release/next/VALIDATION.json',
           notes='No new Lean export of the factorial formula, literature identity or radial Taylor reconstruction. Production Lean sources are unchanged from dd977048.')
rows.append(new)
with p.open('w',encoding='utf-8',newline='') as f:
    ww=csv.DictWriter(f,fieldnames=fields,delimiter='\t',quoting=csv.QUOTE_ALL,lineterminator='\n')
    ww.writeheader();ww.writerows(rows)

current=['lean/README.md','lean/COVERAGE.md','lean/CORRESPONDENCE.md',
         'lean/CONTINUATION_SOURCE_CORRESPONDENCE.md','lean/tools/continuation/README.md']
for name in current:
    s=(repo/name).read_text(encoding='utf-8')
    s=s.replace('v0.3.0-rc1','v0.3.0-rc2').replace('v0.1-rc5','v0.1-rc6').replace('manuscript-rc5.tex','manuscript-rc6.tex')
    s=s.replace('a79c2f5701111b5234bbc0ff8481e75aec8c21d0',math).replace('2142867e9b269c75375a90f55aa8ce0896853508',blob)
    put(name,s)

p='lean/COVERAGE.md';s=(repo/p).read_text()
s=s.replace('full physical arc consequence and closed factorial amplitude are not new Lean exports.',
            'full physical arc consequence, closed factorial amplitude and Proposition F.1 complete-amplitude conversion are manuscript-only.')
s+='\nProduction Lean sources are byte-identical to verified commit `'+base+'`. The new candidate binds a new manuscript snapshot, version/configuration and source ledger, so its proof and verification identities and execution receipts are distinct. No earlier receipt is reassigned.\n'
put(p,s)
p='lean/CORRESPONDENCE.md';s=(repo/p).read_text()
s+='\nProposition F.1 is a new manuscript-only source claim. Its comparison of the printed scalar with the complete observable and its radial Taylor reconstruction are not claimed as Lean declarations. The existing formal first-amplitude and physical-product endpoints remain unchanged. The rc5 source snapshot and reports retain their historical identities at `'+base+'`.\n'
put(p,s)
p='lean/README.md';s=(repo/p).read_text()
s+='\nThe rc6 addition proves the complete-amplitude conversion in Proposition F.1. That literature identity and the factorial/radial Taylor calculations are manuscript-only. All 1075 production Lean source files are unchanged from verified rc5/Lean v0.3.0-rc1 commit `'+base+'`; metadata and source identities are newly bound and acceptance is rerun.\n'
put(p,s)
put('lean/GAP_MANIFEST.md','''# Candidate obligations and retained boundaries

E3 is eliminated from the actual canonical proof chain. The normalized NB theorem has no external physics or fixed-order premise; physical identification retains E1/E2 and positive coupling. No lower-order or tail estimate is introduced as an external assumption.

Manuscript rc6 Proposition F.1 closes the comparison of the inspected McCoy–Maillard printed scalar with the complete selected-family susceptibility coefficient: 4R_N(-theta_*)=-4iR_N(theta_*). The observable is fixed by the cited integral, and the physical root, radial variable and chart degeneracy are derived. This conversion, the factorial evaluation and radial Taylor reconstruction remain manuscript-only. No statement about Nickel's unread original intended convention or degenerate endpoints is imported.

The quantitative finite-prime covering is also manuscript-only. The exact finite-arc 80*pi² shortcut remains rejected; its optional asymptotic leading constant has separate scope. Existing auxiliary-clause and off-path interface distinctions remain in [coverage](COVERAGE.md).

There is no remaining mathematical obligation for the stated selected-family amplitude conversion. Independent human/group review, exhaustive priority, and attribution of the unavailable original Nickel derivation remain outside the completed internal checks. Earlier open-comparison wording belongs to verified rc5/v0.3.0-rc1 at dd977048, preserved in the [version ledger](../docs/VERSIONS.md). Failed or unavailable executions belong to [validation](../release/next/VALIDATION.json).
''')
p='lean/CONTINUATION_AUXILIARY_SCOPE.md';s=(repo/p).read_text()
s+='\nThe rc6/Lean v0.3.0-rc2 normalization comparison is manuscript-only and changes no auxiliary Lean statement or production dependency. The verified predecessor and its reports are scoped in the version ledger.\n'
put(p,s)
print(json.dumps({'source_commit':math,'source_blob':blob,'production_files_unchanged':len(production),
                  'ledger_rows':len(rows),'endpoint_contract':len(contract['endpoints'])},indent=2))
