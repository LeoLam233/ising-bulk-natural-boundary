"""Bind the untouched verified parent and the original-source reading evidence."""
import hashlib, json, pathlib, subprocess

work = pathlib.Path(__file__).resolve().parent
repo = work.parent/'repo'
base = 'dd977048c2380e775d83b97ae1fba354c04c349a'
def git(*args):
    return subprocess.check_output(['git','-c','safe.directory=*',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip() == base
historical = []
for name in ('paper/next/manuscript.tex','paper/next/manuscript.pdf','paper/next/BUILD.json',
             'paper/next/LABEL_INDEX.json','lean/SOURCE.json','lean/TOOLCHAIN_FREEZE.json',
             'lean/ci/payload.json','lean/ci/accepted_identity.json','release/CURRENT_STATUS.json',
             'release/next/VALIDATION.json','release/next/MANIFEST.json',
             'release/next/evidence/INDEX.json','release/next/evidence/execution-records.tar.gz'):
    data = git('show',base+':'+name)
    historical.append({'path':name,'git_blob':git('rev-parse',base+':'+name).decode().strip(),
                       'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
retained = []
for name in ('lean/source_snapshot/manuscript-rc5.tex', 'docs/UPGRADE_v0.3.0-rc1.md',
             'docs/MATHEMATICAL_AUDIT_v0.3.0-rc1.md','docs/CONSISTENCY_AUDIT_v0.3.0-rc1.md'):
    data = git('show',base+':'+name)
    assert (repo/name).read_bytes() == data
    retained.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
record = dict(schema='ising-amplitude-baseline-v1', verified_commit=base,
              verified_tree=git('rev-parse',base+'^{tree}').decode().strip(),
              manuscript='v0.1-rc5', lean_candidate='v0.3.0-rc1',
              research_branch='research/amplitude-identification-20261017',
              existing_pr='https://github.com/LeoLam233/ising-bulk-natural-boundary/pull/3',
              historical_assets_in_immutable_git=historical, retained_files=retained,
              production_Lean_sources='All 1075 production Lean source files remain byte-identical to this commit; checked against its proof payload.',
              preservation='The verified commit remains an ancestor, with its own manuscript/PDF, identities, receipts and historical reports. No release tag is moved.')
(repo/'provenance/AMPLITUDE_BASELINE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')

sources = json.loads((work/'source-page-index.json').read_text())
sources[0]['inspected_page_locators'] = [[7,'(44)-(45), printed 8'],[10,'(64), printed 11'],[11,'(67)-(70), printed 12']]
for entry, url in zip(sources, [
    'https://arxiv.org/pdf/1203.1456v1',
    'https://www.lptmc.jussieu.fr/files/maillard/PUB2/The_Importance_Ising.pdf',
    'https://arxiv.org/pdf/0808.0763v1',
    'https://arxiv.org/pdf/cond-mat/0103074v1',
]):
    entry['url'] = url
    entry['pdf_redistributed'] = False
out = dict(schema='ising-amplitude-source-record-v1', sources=sources,
           review_equation_crosswalk={'amplitude':{'arxiv_v1':69,'journal':70},
                                      'angle':{'arxiv_v1':70,'journal':71}},
           source_typography='Review (64) prints a plus sign inconsistent with its following explicit roots and angle relation; the actual integral and Orrick et al. (3.24) fix the relation used.',
           access_attempts=[
               {'source':'Nickel 1999 DOI 10.1088/0305-4470/32/21/303',
                'routes':['web reader','Windows HTTPS','WSL HTTPS'],
                'result':'No paper content. HTTP 200 responses were HTML from validate.perfdrive.com, not PDFs.'},
               {'source':'Nickel 2000 DOI 10.1088/0305-4470/33/8/313',
                'routes':['web reader','Windows HTTPS','WSL HTTPS','normal in-app browser'],
                'result':'No paper content. Browser visibly displayed a CAPTCHA. No challenge was solved.'},
               {'source':'Maillard institutional journal PDF',
                'routes':['Windows urllib','Windows curl','WSL curl','WSL urllib'],
                'result':'Windows TLS trust failed. WSL normal TLS verification succeeded, with the PDF hash recorded above. No TLS-validation bypass.'},
               {'source':'Original Nickel paper discovery',
                'routes':['DOI metadata','OpenAlex metadata','focused author and institutional web searches'],
                'result':'Metadata located, but no accessible original text. No statement about Nickel original intended amplitude convention is attributed.'},
           ],
           scope='The conversion concerns the inspected printed scalar and its cited full-site observable. Access failures limit historical attribution, not the derived selected-family conversion.')
(repo/'checks/amplitude_identification/SOURCES.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'baseline_assets':len(historical),'retained_files':len(retained),'primary_pdfs_read':len(sources)}))
