"""Collect actual Linux control receipts after the complete wrapper succeeds."""
from pathlib import Path
import hashlib, json, shutil

work=Path(__file__).resolve().parent
summary=json.loads((work/'logs/acceptance-rc2-01/summary.json').read_text())
assert summary['all_executed_stages_passed']
project=Path('/tmp/ising-amplitude-rc2-20261017-a1/lean')
dest=work/'linux-evidence-rc2'
dest.mkdir(exist_ok=False)
sources=[]
for p in (project/'control_packet/continuation/results').rglob('*'):
    if p.is_file() and 'payload' not in p.relative_to(project).parts:sources.append(p)
for directory in (project/'.local').glob('unused-e3-control-*'):
    sources.extend(p for p in directory.rglob('*') if p.is_file())
entries=[]
for path in sorted(sources):
    rel=path.relative_to(project)
    target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,target)
    entries.append(dict(path=rel.as_posix(),bytes=path.stat().st_size,
                        sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(dest/'INDEX.json').write_text(json.dumps(dict(source_project=str(project),files=entries,
    scope='Actual fixture/verifier streams and receipts; throwaway payload/compiled trees omitted.'),indent=2)+'\n')
print(json.dumps({'copied_files':len(entries),'unprivileged_uid':summary['unprivileged_uid']}))
