"""Review-aid cross-checks after mathematical acceptance; no automatic math verdict."""
from pathlib import Path
import collections, csv, io, json, subprocess

w=Path(__file__).resolve().parent;r=w.parent/'repo'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
scan=read(r/'.local/rc2-post-validation-scan.json')
seq=read(w/'logs/acceptance-rc2-01/full/sequence.result.json')
assert seq['status']=='CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND' and scan['created_utc']>seq['finished_utc']
def previous(name):return subprocess.check_output(['git','-c','safe.directory=*','show','dd977048:'+name],cwd=r)
old={e['source_label']:e for e in csv.DictReader(io.StringIO(previous('lean/CLAIM_LEDGER.tsv').decode()),delimiter='\t')}
new={e['source_label']:e for e in csv.DictReader((r/'lean/CLAIM_LEDGER.tsv').open(encoding='utf-8'),delimiter='\t')}
assert len(old)==31 and len(new)==32 and set(new)-set(old)=={'prop:amplitudecomparison'}
changes={k:{c:[old[k][c],v] for c,v in row.items() if c!='source_commit' and old[k][c]!=v}
         for k,row in new.items() if k in old}
changes={k:v for k,v in changes.items() if v}
assert set(changes)=={'eq:amplitudeclosed'} and set(changes['eq:amplitudeclosed'])=={'statement_equivalence'}
assert new['eq:amplitudeclosed']['status']==new['prop:amplitudecomparison']['status']=='MANUSCRIPT_ONLY'
unchanged=[]
for name in ('.github/workflows/lean-full-acceptance.yml','.github/workflows/lean-acceptance.yml',
             '.github/workflows/release-v0.2.0.yml','lean/ci/prepare_release_assets.py'):
    assert (r/name).read_bytes()==previous(name);unchanged.append(name)
current=[e for e in scan['matches'] if e['category']=='current_candidate']
print(json.dumps(dict(post_validation_scan_utc=scan['created_utc'],categories=scan['categories'],
    inventory_files=len(scan['inventory']),text_files=scan['text_files_scanned'],
    current_context_matches=len(current),current_hit_paths=dict(collections.Counter(e['path'] for e in current)),
    ledger_rows=32,existing_rows_other_than_source_commit_unchanged=30,
    sole_existing_row_scope_update=changes,new_row_scope=new['prop:amplitudecomparison'],
    workflows_and_historical_publisher_unchanged=unchanged,
    scope='All-file phrase inventory plus precise ledger/configuration cross-check. Human/AI contextual review is separately recorded; this output is not an automatic semantic or mathematical verdict.'),indent=2))
