"""Observe this exact head's two push workflows; do not reuse cached old verdicts."""
from pathlib import Path
import argparse, datetime, json, time, urllib.request

p=argparse.ArgumentParser();p.add_argument('--head',required=True);a=p.parse_args()
assert len(a.head)==40 and all(c in '0123456789abcdef' for c in a.head)
out=Path(__file__).resolve().parent/'remote-rc2';out.mkdir(exist_ok=False)
api='https://api.github.com/repos/LeoLam233/ising-bulk-natural-boundary'
last=None
for probe in range(161):
    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    request=urllib.request.Request(api+'/actions/runs?head_sha='+a.head+'&per_page=30&ising_probe='+str(time.time_ns()),
        headers={'User-Agent':'IsingCandidateAcceptance','Accept':'application/vnd.github+json','Cache-Control':'no-cache'})
    try:
        with urllib.request.urlopen(request,timeout=30) as response:
            result=json.load(response)
            rate={k:response.headers.get(k) for k in ('X-RateLimit-Remaining','X-RateLimit-Reset')}
        runs=[r for r in result['workflow_runs'] if r['head_sha']==a.head and r['event']=='push'
              and r['path'] in ('.github/workflows/lean-full-acceptance.yml','.github/workflows/lean-acceptance.yml')]
        paths={r['path'] for r in runs}
        if len(runs)!=len(paths):
            # A rerun's highest attempt for a workflow is the current one.
            by_path={}
            for r in runs:
                if r['path'] not in by_path or (r['run_attempt'],r['id'])>(by_path[r['path']]['run_attempt'],by_path[r['path']]['id']):by_path[r['path']]=r
            runs=list(by_path.values())
        record={'observed_utc':now,'head':a.head,'rate_limit':rate,'workflow_runs':runs}
        (out/f'probe-{probe:03}.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
        state=[(r['id'],r['status'],r['conclusion']) for r in runs]
        if state!=last:
            print(json.dumps({'observed_utc':now,'head':a.head,'states':state}),flush=True);last=state
        if len(runs)==2 and all(r['status']=='completed' for r in runs):
            (out/'final-runs.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
            passed=all(r['conclusion']=='success' for r in runs)
            print('BOTH_EXACT_HEAD_WORKFLOWS_PASSED' if passed else 'COMPLETED_WORKFLOW_HAS_NON_SUCCESS_CONCLUSION',flush=True)
            raise SystemExit(0 if passed else 1)
        if int(rate['X-RateLimit-Remaining'] or 0)<5:raise SystemExit('Public API quota is low; connected workflow tools remain available. No CI failure inferred.')
    except (OSError,ValueError) as exc:
        (out/f'error-{probe:03}.json').write_text(json.dumps({'observed_utc':now,'error':str(exc)})+'\n',encoding='utf-8')
        print(json.dumps({'observed_utc':now,'transient_observation_error':str(exc),'no_failure_inferred':True}),flush=True)
    time.sleep(45)
raise SystemExit('Observation window exhausted; no CI failure inferred.')
