"""Record the authoring/accepted-verification separation without changing proof inputs."""
from pathlib import Path
import datetime, json

w=Path(__file__).resolve().parent;r=w.parent/'repo'
read=lambda n:json.loads((r/n).read_text(encoding='utf-8'))
put=lambda n,v:(r/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
ids=read('lean/ci/accepted_identity.json')
assert ids['PROOF_CRITICAL_PAYLOAD_ID']=='90ec278d89e753223f40643715a57dfab9f0c0cb0da9fece1cecd7fd2937c124'
assert ids['VERIFICATION_INPUT_ID']=='6ce45f85328d34344df9ec9dad6add13610f840a40a550db432af2cfe679877c'
note=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    finding='The root command block put PDF regeneration before accepted-hash verification, although regeneration updates PDF/BUILD only.',
    resolution='Separate accepted-checkout diagnostics/verification from regeneration in both README languages, paper guide and machine-readable recipes. Rebuilt PDFs need fresh visual QA/validation/inventory.',
    evidence='Inspected builder writes and acceptance hash checks; no additional failed PDF build is claimed.',
    manuscript_and_pdf_unchanged=True,production_and_Lean_verification_inputs_unchanged=True,
    affected_checks='Fresh all-file text scan, current semantic/manifest verifier and staged whitespace check; exact-head CI recorded separately.',
    scan_archive_path='final-checks/rc2-documentation-refresh-scan.json')
v=read('release/next/VALIDATION.json')
v['reproduce']=['python scripts/verify_candidate.py']+[x for x in v['reproduce'] if x not in ('python scripts/build_candidate_paper.py','python scripts/verify_candidate.py')]
if 'cd ..; python scripts/verify_candidate.py' not in v['reproduce']:
    v['reproduce'].insert(-1,'cd ..; python scripts/verify_candidate.py')
v['paper_regeneration']=dict(command='python scripts/build_candidate_paper.py',
    scope='Authoring/regeneration in a separate checkout. The rebuilt PDF needs its own visual QA, validation and inventory before acceptance. Source edits additionally require matching Lean source identities.')
v['consistency_audit']['post_acceptance_documentation_correction']=note
put('release/next/VALIDATION.json',v)
c=read('release/next/CONSISTENCY_RESULT.json');c['post_acceptance_documentation_correction']=note
put('release/next/CONSISTENCY_RESULT.json',c)
print(json.dumps(note,indent=2))
