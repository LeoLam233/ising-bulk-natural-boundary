"""Run an argv without a shell and preserve executed command, output and status."""
import argparse, datetime, hashlib, json, os, pathlib, subprocess, time

p = argparse.ArgumentParser()
p.add_argument('--cwd', required=True)
p.add_argument('--logs', required=True)
p.add_argument('--name', required=True)
p.add_argument('argv', nargs=argparse.REMAINDER)
a = p.parse_args()
argv = a.argv[1:] if a.argv[:1] == ['--'] else a.argv
if ('/' in argv[0] or '\\' in argv[0]) and not pathlib.Path(argv[0]).is_absolute():
    argv[0] = str((pathlib.Path(a.cwd) / argv[0]).resolve())
root = pathlib.Path(a.logs)
root.mkdir(parents=True, exist_ok=True)
out, err = root / (a.name + '.stdout'), root / (a.name + '.stderr')
if out.exists() or err.exists():
    raise SystemExit('Refusing to overwrite a command receipt: ' + a.name)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t = time.monotonic()
env = os.environ.copy()
env['PYTHONIOENCODING'] = 'utf-8'
env['PYTHONDONTWRITEBYTECODE'] = '1'
with out.open('wb') as so, err.open('wb') as se:
    try:
        r = subprocess.run(argv, cwd=a.cwd, env=env, stdout=so, stderr=se)
        code = r.returncode
    except OSError as exc:
        se.write(str(exc).encode('utf-8'))
        code = 127
receipt = dict(argv=argv, cwd=str(pathlib.Path(a.cwd).resolve()), started_utc=started,
               seconds=round(time.monotonic()-t, 3), exit_code=code,
               stdout_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
               stderr_sha256=hashlib.sha256(err.read_bytes()).hexdigest())
(root / (a.name + '.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt), flush=True)
print(out.read_text(encoding='utf-8', errors='replace')[-3500:], flush=True)
print(err.read_text(encoding='utf-8', errors='replace')[-1500:], flush=True)
raise SystemExit(code)
