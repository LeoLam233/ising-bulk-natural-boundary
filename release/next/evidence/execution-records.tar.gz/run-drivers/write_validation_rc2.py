"""Write acceptance records only from the completed rc2 gate and fresh audit scan."""
from pathlib import Path
import datetime, hashlib, json, re

work=Path(__file__).resolve().parent
r=work.parent/'repo'
read=lambda name:json.loads((r/name).read_text(encoding='utf-8'))
def put(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
ids=read('lean/ci/accepted_identity.json')
seq=read('release/next/evidence/clean-sequence.json')
assert seq['status']=='CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND'
assert all(seq[k]==v for k,v in ids.items())
wrapper=read('release/next/evidence/acceptance-summary.json')
assert wrapper['all_executed_stages_passed'] and wrapper['unprivileged_uid']!=0
assert read('release/next/evidence/production-controls-13.json')['case_count']==13
scan=read('.local/rc2-post-validation-scan.json')
assert scan['created_utc']>seq['finished_utc']
build=read('paper/next/BUILD.json')
qa=read('release/next/PDF_QA.json')
diag=read('release/next/evidence/historical-diagnostics.json')
neg=read('release/next/evidence/unused-E3-control.json')
amp=read('release/next/evidence/amplitude-checks.json')
assert diag['all_reproduced'] and neg['passed'] and amp['status']=='PASS'
rootlog=(work/'logs/acceptance-rc2-01/full/01_clean_project_build.stdout.log').read_text(encoding='utf-8')
jobs=re.search(r'Build completed successfully \((\d+) jobs\)',rootlog)
assert jobs,'No actual successful root-job count found'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
v=dict(schema='ising-next-validation-v1',status='VERIFIED_CANDIDATE',created_utc=now,
       manuscript='v0.1-rc6',lean_candidate='v0.3.0-rc2',
       development_branch='research/next-internal-regularity-20261017',
       research_branch='research/amplitude-identification-20261017',
       mathematical_source_commit='dce74bc7ce1106e96b0d754360ac9fbed5f2feea',
       preserved_previous_verified_commit='dd977048c2380e775d83b97ae1fba354c04c349a',
       identities=ids,clean_acceptance_sequence='release/next/evidence/clean-sequence.json',
       counts=dict(production_subtree_modules=seq['production_module_count'],production_with_public_root=1075,
                   safe_project_declarations=seq['audited_safe_declaration_count'],exact_endpoints=seq['endpoint_count'],
                   root_build_jobs=int(jobs[1]),manifest_controls=13,production_controls_before_build=12,
                   production_controls_full_variant=13,ordinary_lean_controls=7,additional_unused_E3_control=1),
       axiom_union=seq['axiom_union'],fresh_kernel_replay_exit=seq['fresh_kernel_replay_exit'],
       canonical_dependencies=dict(normalized_external_premises=[],physical_external_premises=['E1','E2'],
                                   E3_transitively_absent=True,compiled_types_and_proof_bodies_traversed=True,
                                   production_Lean_sources_unchanged_from_verified_predecessor=True,
                                   endpoint_domains_and_conclusions_retained=True),
       dependency_negative_control=neg,
       historical_diagnostics=dict(all_reproduced=True,checks=6,numpy='2.3.5',sympy='1.14.0',mpmath='1.3.0',
                                   continuous_or_infinite_certificate=False,receipt='evidence/historical-diagnostics.json'),
       new_checks=dict(exit_code=0,receipt='evidence/new-mathematical-checks.json',
                       scope='Retained rc5 algebra, Mehta, amplitude and finite-prime diagnostics, rerun under pinned packages.',
                       continuous_or_infinite_certificate=False),
       amplitude_checks=dict(exit_code=0,receipt='evidence/amplitude-checks.json',
                             script_sha256=hashlib.sha256((r/'checks/amplitude_identification/check_amplitude.py').read_bytes()).hexdigest(),
                             exact_symbolic_checks=9,exact_cyclotomic_instance=dict(p=11,N=22,physical_angular_centers=4),
                             quadrature_cases=3,quadrature_dps=90,continuous_asymptotic_certificate=False,
                             supplementary_exact_phase_coordinate_checks=3,
                             supplementary_archive_path='additional-math/phase-coordinate-results.json'),
       paper={**build,'pages':qa['pages'],'passes':3,'visual_qa':'release/next/PDF_QA.json',
              'all_pages_rendered_and_inspected':True},
       consistency_audit=dict(report='docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md',
                              mathematical_sequence_finished_utc=seq['finished_utc'],
                              fresh_scan_started_utc=scan['created_utc'],
                              post_validation_inventory_files=len(scan['inventory']),
                              text_files_scanned=scan['text_files_scanned'],
                              protected_original_assets=211,preserved_former_metadata_records=17,
                              retained_rc5_snapshot_reports=4,immutable_predecessor_assets_checked=13,
                              verification_command='python scripts/verify_candidate.py',
                              final_inventory='release/next/MANIFEST.json'),
       remaining_current_inconsistencies=[],failed_attempts_and_unavailable_checks='release/next/FAILURES.md',
       executed_record_archive='release/next/evidence/execution-records.tar.gz',
       executed_record_index='release/next/evidence/INDEX.json',
       manuscript_only=['factorial amplitude identity','complete literature-amplitude conversion',
                        'radial Taylor reconstruction','quantitative finite-prime covering'],
       remaining_mathematical_obligations_for_stated_amplitude_conversion=[],
       source_attribution_limit='Original Nickel 1999/2000 text could not be read. No original intended convention or original-paper error is attributed; the inspected review scalar/full-observable conversion is derived.',
       reproduce=[
           'python scripts/build_candidate_paper.py',
           'python scripts/reproduce.py',
           'python checks/next_version/run_checks.py --output NEW_RC5_DIAGNOSTIC_RESULT.json',
           'python checks/amplitude_identification/check_amplitude.py --output NEW_AMPLITUDE_RESULT.json',
           'cd lean; python3 tools/continuation/preflight.py --lean-bin OFFICIAL_LEAN_BIN --output NEW_PREFLIGHT.json',
           'python3 ci/verify_payload.py --expected-id '+ids['PROOF_CRITICAL_PAYLOAD_ID']+' --dependencies',
           'python3 control_packet/continuation/run_manifest_controls.py',
           'python3 control_packet/continuation/run_remediation_controls.py',
           'python3 tools/continuation/final_gate.py --lean-bin OFFICIAL_LEAN_BIN --approved-preflight NEW_PREFLIGHT.json --logs NEW_LOG_DIRECTORY --threads 2 --execute',
           'python3 control_packet/continuation/run_remediation_controls.py --shadow-tree .lake/build/lib/lean/IsingBulk',
           'cd ..; python scripts/verify_candidate.py',
           'python checks/amplitude_identification/repository_controls.py --output NEW_REPOSITORY_CONTROL_RESULT.json'],
       evidence_scope=[
           'The completed gate says CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND; its own audit flags are not relabeled. The scoped mathematical and repository audits are separate.',
           'Fresh replay uses the exact official Lean implementation already pinned. Build and replay share that kernel. Cached dependency binary/source correspondence remains trusted; no complete Mathlib source rebuild or second kernel.',
           'Finite exact identities and diagnostics are not a continuous asymptotic or infinite-tail certificate. The analytic arguments establish the general conversion.',
           'Function coefficients are radial first fractional coefficients modulo finite Taylor polynomials. No new convergent full Puiseux or uniform sectoral expansion theorem.',
           'This receipt records local acceptance. Later remote CI and final Git head identity are recorded separately, without self-referential receipt rewriting.'
       ],historical_releases_modified=False,published_release=False,default_branch_merged=False,
       independent_human_review=False,peer_reviewed=False)
control=r/'.local/repository-controls-full-tree.json'
if control.is_file():
    result=json.loads(control.read_text())
    assert result['all_controls_pass'] and result['case_count']==5 and result['input_tree_unchanged']
    v['repository_guard_controls']=dict(all_controls_pass=True,negative_cases=5,positive_before_after=True,
                                        input_tree_unchanged=True,receipt='evidence/repository-controls.json')
    put('release/next/evidence/repository-controls.json',result)
put('release/next/VALIDATION.json',v)
status=read('release/CURRENT_STATUS.json')
status.update(acceptance_status='VERIFIED_CANDIDATE_LOCAL_ACCEPTANCE',
              consistency_audit='../docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md')
put('release/CURRENT_STATUS.json',status)
print(json.dumps({'status':v['status'],'counts':v['counts'],'identities':ids},indent=2))
