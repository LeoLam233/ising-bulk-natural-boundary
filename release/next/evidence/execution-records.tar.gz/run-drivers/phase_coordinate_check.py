"""Supplemental exact checks of the report's phase and w-coordinate identities."""
import json, pathlib, sympy as s
h=s.symbols('h',integer=True,nonnegative=True)
z=s.symbols('z',nonzero=True)
delta=s.symbols('delta')
theta=s.symbols('theta',real=True)
nu=2*(2*h+1)**2-s.Rational(3,2)
w=lambda q:q/(2*(1+q*q))
rho=1-w(z/(1-delta))/w(z)
checks={
    'selected_prime_phase_parity':s.expand(nu-(8*h*(h+1)+s.Rational(1,2))),
    'w_coordinate_jacobian':s.simplify(s.diff(rho,delta).subs(delta,0)-(z*z-1)/(z*z+1)),
    'magnetization_polar_identity':s.simplify(s.expand_complex(
        1-s.exp(-4*s.I*theta)-2*s.sin(2*theta)*s.exp(s.I*(s.pi/2-2*theta)))),
}
assert all(value==0 for value in checks.values()),checks
result=dict(status='PASS',symbolic_checks={name:str(value) for name,value in checks.items()},
            scope='Exact identities. Branch admissibility is proved analytically in the report, not by a CAS power simplification.')
path=pathlib.Path(__file__).with_name('phase-coordinate-results.json')
assert not path.exists()
path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result,indent=2))
