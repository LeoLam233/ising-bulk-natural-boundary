"""Finalize the post-validation audit only from completed, current receipts."""
from pathlib import Path
import argparse, datetime, json

p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');a=p.parse_args()
w=Path(__file__).resolve().parent;r=w.parent/'repo'
read=lambda n:json.loads((r/n).read_text(encoding='utf-8'))
seq=read('release/next/evidence/clean-sequence.json')
assert seq['status']=='CHECK_SEQUENCE_PASSED_NOT_AUDIT_ROUND'
scan=read('.local/rc2-post-validation-scan.json')
assert scan['created_utc']>seq['finished_utc']
ids=read('lean/ci/accepted_identity.json')
assert all(seq[k]==v for k,v in ids.items())
controls=None
if a.final:
    controls=read('.local/repository-controls-full-tree.json')
    assert controls['all_controls_pass'] and controls['case_count']==5 and controls['input_tree_unchanged']
    assert controls['input_tree_before_id']==controls['input_tree_after_id'] and controls['input_tree_files']>=1416
    final_scan=read('.local/rc2-final-text-scan.json')
    assert final_scan['created_utc']>=scan['created_utc']
    guard=json.loads((w/'logs/repository-candidate-bootstrap.stdout').read_text(encoding='utf-8'))
    assert guard['status']=='VERIFIED_CANDIDATE'
    status='POST_VALIDATION_AUDIT_COMPLETED'
else:
    status='POST_VALIDATION_SCAN_REVIEWED_FINAL_GUARD_IN_PROGRESS'

result=dict(manuscript='v0.1-rc6',lean_candidate='v0.3.0-rc2',status=status,
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    mathematical_sequence_finished_utc=seq['finished_utc'],
    mandatory_post_validation_scan_utc=scan['created_utc'],
    post_validation_scan_inventory_files=len(scan['inventory']),text_files_scanned=scan['text_files_scanned'],
    current_phrase_matches_reviewed=sum(e['category']=='current_candidate' for e in scan['matches']),
    automatic_scan_is_semantic_verdict=False,protected_historical_files=211,preserved_record_copies=17,
    verified_predecessor_assets=13,retained_rc5_files=4,production_files_including_root=1075,
    production_sources_unchanged_from_verified_predecessor=True,endpoint_count=seq['endpoint_count'],
    source_labels=68,rc5_label_numbers_preserved=67,old_rc4_label_numbers_preserved=65,
    safe_project_declarations=seq['audited_safe_declaration_count'],fresh_kernel_replay_exit=seq['fresh_kernel_replay_exit'],
    proof_id=ids['PROOF_CRITICAL_PAYLOAD_ID'],verification_id=ids['VERIFICATION_INPUT_ID'],
    report='docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md',
    remaining_current_inconsistencies=[],historical_unavailable_original_Nickel_text=True,
    unresolved_mathematical_obligations_for_stated_conversion=[],
    manifest_excludes_itself=True,final_guard_command='python scripts/verify_candidate.py')
if a.final:
    result.update(repository_guard_negative_cases=5,repository_guard_positive_before_after=True,
                  repository_guard_input_files=controls['input_tree_files'],
                  repository_guard_before_after_id=controls['input_tree_before_id'],
                  final_text_scan_utc=final_scan['created_utc'],final_text_scan_inventory_files=len(final_scan['inventory']))
(r/'release/next/CONSISTENCY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')

if a.final:
    report=r/'docs/CONSISTENCY_AUDIT_v0.3.0-rc2.md'
    text=report.read_text(encoding='utf-8')
    old='Status: **IN PROGRESS**. The mathematical conversion and manuscript checks are complete. Fresh Lean acceptance is running; the mandatory post-validation scan and final acceptance record are not yet complete. This working record is finalized only after those checks.'
    assert old in text
    text=text.replace(old,'Status: **POST-VALIDATION AUDIT COMPLETED**. The fresh clean Lean acceptance, mandatory subsequent all-file scan, manual contextual review, isolated repository-guard attacks and positive checks have passed. The final inventory is regenerated after assembling these records and checked again before commit.')
    old_end='The final pass will refresh this report with the executed clean gate, a fresh all-file inventory/phrase scan, isolated negative controls for the repository guard, and the final manifest check. [Mathematical report](AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md) · [Validation](../release/next/VALIDATION.json).'
    assert old_end in text
    final=f'''## Executed post-validation acceptance

The mathematical sequence finished at `{seq['finished_utc']}`. The mandatory fresh inventory/phrase scan began later, at `{scan['created_utc']}`: {len(scan['inventory'])} files, {scan['text_files_scanned']} UTF-8 text files and {result['current_phrase_matches_reviewed']} current-context matches. All matches were reviewed in context. The scan is a review aid, not an automatic semantic verdict. The final follow-up scan is separately retained, with {len(final_scan['inventory'])} files; changing audit/evidence inventories do not reassign the earlier scan's timestamp or hashes.

The review included unmodified production/source-facing Lean modules, fixture and control code, both active CI workflows, the old publication workflow/helper, original premises and release records, current manifests, ledger, generated PDF/labels, and current documents in both languages. The 1075 production Lean sources are independently required to be byte-identical to dd977048 and were freshly built/replayed. All 211 protected originals, 17 historical metadata copies, four retained rc5 snapshot/reports and 13 immutable predecessor artifact identities pass their preservation guards. Original release-note blocks remain exact suffixes.

| Check | Executed result |
|---|---|
| Full public-root build | 4838 jobs passed; 1074 subtree modules plus public root |
| Compiled axiom traversal | {seq['audited_safe_declaration_count']} safe declarations; only propext, Classical.choice, Quot.sound |
| Exact endpoints | {seq['endpoint_count']} passed; unchanged formal conclusions |
| Compiled canonical types and proof bodies | E3 and published transfer helpers absent; internal lower-order route reachable |
| Manifest / production controls | 13 / 12 prebuild plus 13 postbuild passed |
| Lean controls / additional unused-E3 control | 7 / 1 passed |
| Official fresh kernel replay | Exit {seq['fresh_kernel_replay_exit']} |
| Historical / retained rc5 / new amplitude diagnostics | All executed; finite/exact/numerical scopes distinguished |
| Manuscript | Three successful passes, 47 pages, all pages rendered/inspected, 68 labels; 67 rc5 numbers retained |
| Repository guard attacks | Five expected rejections in an isolated clone; positive runs before/after; input unchanged |

One further current-doc discrepancy was found during this pass: the prebuild production suite was described as 13 cases. The executable prebuild suite has 12; `--shadow-tree` after the build adds case 13. The Lean reproduction instructions, validation counts and failure record now distinguish both actual executions. No Lean verifier/fixture changes were needed for this count correction, so the accepted Lean verification identity remains unchanged.

The first isolated repository-control launch failed in the Windows process sandbox before any negative ran; the authorized native retry passed. Its initial unchanged-input check covered seven critical files. The final control source expands this to all {controls['input_tree_files']} tracked/unignored files before and after the run, and binds its own source among persistent critical inputs. All five attacks and both positive checks were rerun. The earlier bounded-scope success and launcher failure remain separate raw records; only the final complete-inventory receipt supports the current unchanged-tree statement. These repository-check changes do not alter the accepted Lean verification inputs.

## Current versus historical authority

The new canonical pair is rc6 / Lean v0.3.0-rc2. Source/PDF/snapshot/configuration/ledger/current-status records share those versions. Proposition F.1 is explicitly manuscript-only in all current coverage records and the 32-row source ledger; no new formal amplitude export is advertised. FIRST/NB still exclude E3 and the physical endpoint retains E1/E2. The old source-facing comparison helper containing E3 remains legitimate and off the canonical dependency chain.

The original rc4/v0.2.1 assets, rc5 snapshot/reports, audit verdicts, old publication workflow and helper retain their own scope through the current version index. The old root manifest is an rc4 authority; `release/next/MANIFEST.json` is the current inventory. The active workflows use the existing PR #3 branch. The separate research branch is fast-forwarded into it after local acceptance. Remote CI, final Git head and transport receipts are recorded separately after the local artifact commit, avoiding a self-referential release hash and reassignment of old CI success.

## Remaining issues and evidence limits

There is no known unresolved contradiction among current authoritative artifacts, and no remaining mathematical obligation for the stated selected-family amplitude conversion. Original Nickel publisher text remains inaccessible; no claim attributes its intended convention or an original-paper error. This historical access limit is distinguished from the completed comparison of the directly inspected review scalar and cited full observable. Other sheets, degenerate angles/endpoints and odd orders remain outside the theorem.

The audits are internal AI work. Hashes, compilation and finite diagnostics do not certify the analytic proof. The official replay uses the same kernel as compilation, with pinned dependency-cache/source correspondence trusted; no second kernel, complete Mathlib source rebuild or independent human expert certification is claimed. The scoped mathematical audit and mechanical gate retain their separate completion language.

[Mathematical report](AMPLITUDE_IDENTIFICATION_v0.3.0-rc2.md) · [Validation](../release/next/VALIDATION.json) · [Machine-readable discrepancy/acceptance result](../release/next/CONSISTENCY_RESULT.json).
'''
    report.write_text(text.replace(old_end,final).rstrip()+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result,indent=2))
