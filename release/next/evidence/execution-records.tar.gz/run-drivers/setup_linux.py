"""Create this run's isolated Linux build directory; never modify source caches."""
import hashlib, json, pathlib, shutil, subprocess
source = pathlib.Path('/mnt/i/Codex/_Projectless/2026-10-17/ising-bulk-natural-boundary-autonomous-research-2/work/repo/lean')
dest = pathlib.Path('/tmp/ising-next-20261017-a2/lean')
if dest.exists():
    raise SystemExit('Build directory already exists')
dest.parent.mkdir(parents=True)
shutil.copytree(source, dest)
base = pathlib.Path('/home/ldh/opus_audit_v1/build/lean/.lake/packages')
(dest / '.lake').mkdir(exist_ok=True)
subprocess.run(['cp', '-a', '--reflink=auto', str(base), str(dest / '.lake/packages')], check=True)
runtime = pathlib.Path('/home/ldh/.elan/toolchains/leanprover--lean4---v4.34.1/bin')
manifest = json.loads((dest/'lake-manifest.json').read_text())
for dep in manifest['packages']:
    path = dest/'.lake/packages'/dep['name']
    head = subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'], text=True).strip()
    assert head == dep['rev'], (dep['name'], head, dep['rev'])
    assert not subprocess.check_output(['git','-C',str(path),'status','--porcelain','--untracked-files=no'],text=True)
print(json.dumps({'build':str(dest),'runtime':str(runtime),'dependencies_verified':len(manifest['packages'])}))
