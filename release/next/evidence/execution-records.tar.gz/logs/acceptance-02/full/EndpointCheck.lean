import IsingBulk
import Lean.Util.CollectAxioms

set_option pp.fullNames true

#check IsingBulk.Tail.common_all_sector_parameters
#check IsingBulk.Tail.originalKSNorm_le_sectors
#check IsingBulk.Tail.constructed_originalKSNorm_le_sectors
#check IsingBulk.Tail.common_intermediateKSNormWindow_radialSeriesSmall
#check IsingBulk.Tail.common_intermediateKSNormWindow_littleO
#check IsingBulk.Tail.common_absoluteUpperTailSmall
#check IsingBulk.Tail.selected_absolute_upper_tail_small
#check IsingBulk.Final.theorem_tail
#check IsingBulk.Final.theorem_conditional
#check IsingBulk.Final.theorem_conditional_physical
#check IsingBulk.Final.theorem_nb
#check IsingBulk.Final.theorem_nb_physical
#check IsingBulk.First.theorem_first
#check IsingBulk.Final.theorem_tail_with_summability
#check IsingBulk.First.selected_lower_orders_fixed_radius_bounded
#check IsingBulk.First.nonNickel_fixed_radius_radial_bound
#check IsingBulk.Tail.selected_actual_pair_bounds
#check IsingBulk.Final.theorem_selected_no_Ck_extension

-- Exact expanded principal proposition checks, bound by verification identity.

/- Ordinary type/application controls through the public root. These examples
are excluded from production imports and production declaration counts. -/
open IsingBulk.First IsingBulk.Branch IsingBulk.Tail IsingBulk.Final
open Filter Asymptotics
open scoped Topology

example {p N : ℕ} {D eps : ℝ}
    (h : 2*(p+1) ≤ N ∧ (N:ℝ) < D*Real.sqrt (-Real.log eps)) :
    2*p+2 ≤ N ∧ (N:ℝ) ≤ D*Real.sqrt (Real.log (1/eps)) :=
  intermediate_window_subset h

example {p order : ℕ} {d : LocalBranchData}
    (cfg : CommonAllSectorParameters p d order) (j : ℕ) (hj : j ≤ order) :
    (∀ᶠ eps : ℝ in 𝓝[>] 0, Summable (fun N =>
      intermediateKSNormWindowTerm p d cfg.eta d.alpha d.tau j cfg.D eps (eps^cfg.beta) N)) ∧
    (fun eps : ℝ => intermediateKSNormWindow p d cfg.eta d.alpha d.tau j cfg.D eps
      (eps^cfg.beta)) =o[𝓝[>] 0] (fun eps : ℝ => (Real.sqrt eps)⁻¹) :=
  common_intermediateKSNormWindow_radialSeriesSmall cfg j hj

example {p : ℕ} (hp : p.Prime) (hp11 : 11 ≤ p) {a b : ℤ}
    (ha : IsingBulk.PrimeFamily.Admissible p a)
    (hb : IsingBulk.PrimeFamily.Admissible p b) (hab : a ≠ b) :
    ∀ j : ℕ, j ≤ (2*p)^2/2-1 →
      (fun eps : ℝ => ∑' n : ℕ, ‖iteratedDeriv j (upperFormFactor (2*(n+p+1)))
        (radialParameter (selectedOrderedChart ha hb).theta eps)‖)
        =o[𝓝[>] 0] (fun eps : ℝ => (Real.sqrt eps)⁻¹) :=
  theorem_tail hp hp11 ha hb hab

example :
    ∀ z : ℂ, ‖z‖ = 1 → ¬ HasExteriorExtension exteriorNormalizedBulk z :=
  theorem_nb

example {J : ℝ} (hJ : 0 < J) {chi : ℂ → ℂ} {M : ℝ → ℂ}
    (hE1 : PhysicalSusceptibilityE1 J chi M) (hE2 : YangMagnetizationE2 M) :
    AnalyticOnNhd ℂ (rightPhysicalBulk J) {s : ℂ | 1 < ‖s‖ ∧ 0 < s.re} ∧
      (∀ x : ℝ, 16 < x → chi (x:ℂ) = rightPhysicalBulk J (x:ℂ)) ∧
      (∀ z : ℂ, ‖z‖ = 1 → ¬ HasPhysicalBoundaryExtension J exteriorNormalizedBulk z) :=
  theorem_nb_physical hJ hE1 hE2

-- Exact FIRST application with no E3 premise.
example {p : ℕ} (hp : p.Prime) (hp11 : 11 ≤ p) {a b : ℤ}
    (ha : IsingBulk.PrimeFamily.Admissible p a) (hb : IsingBulk.PrimeFamily.Admissible p b) (hab : a ≠ b) :
    let k := (2*p)^2/2-1
    let A := selectedOrderedChart ha hb
    let L := localLeadingCoefficient A (2*p-1) k
    L ≠ 0 ∧
      Asymptotics.IsLittleO (𝓝[>] (0:ℝ))
        (fun epsilon => (deriv^[k] (doubleFormFactor (2*p) (sourceRadialPair A.theta epsilon).1))
          (sourceRadialPair A.theta epsilon).2 - (Real.sqrt epsilon:ℂ)⁻¹*(2*L))
        (fun epsilon => (Real.sqrt epsilon:ℂ)⁻¹) ∧
      (∃ e : ℝ, 0 < e ∧ ∀ j : ℕ, j < k → ∃ C : ℝ, 0 ≤ C ∧ ∀ epsilon : ℝ,
        0 < epsilon → epsilon < e →
        ‖(deriv^[j] (doubleFormFactor (2*p) (sourceRadialPair A.theta epsilon).1))
          (sourceRadialPair A.theta epsilon).2‖ ≤ C) ∧
      (∀ N : ℕ, 0 < N → Even N → N < 2*p → ∀ j : ℕ,
        ∃ e C : ℝ, 0 < e ∧ 0 ≤ C ∧ ∀ epsilon : ℝ, 0 < epsilon → epsilon < e →
          ‖(deriv^[j] (doubleFormFactor N (sourceRadialPair A.theta epsilon).1))
            (sourceRadialPair A.theta epsilon).2‖ ≤ C) :=
  theorem_first hp hp11 ha hb hab

-- Complete TAIL application, with explicit positive-parameter convergence.
example {p : ℕ} (hp : p.Prime) (hp11 : 11 ≤ p) {a b : ℤ}
    (ha : IsingBulk.PrimeFamily.Admissible p a)
    (hb : IsingBulk.PrimeFamily.Admissible p b) (hab : a ≠ b) :
    ∀ j : ℕ, j ≤ (2*p)^2/2-1 →
      (∀ eps : ℝ, 0 < eps → Summable (fun n : ℕ =>
        ‖iteratedDeriv j (upperFormFactor (2*(n+p+1)))
          (radialParameter (selectedOrderedChart ha hb).theta eps)‖)) ∧
      (fun eps : ℝ => ∑' n : ℕ, ‖iteratedDeriv j (upperFormFactor (2*(n+p+1)))
        (radialParameter (selectedOrderedChart ha hb).theta eps)‖)
        =o[𝓝[>] 0] (fun eps : ℝ => (Real.sqrt eps)⁻¹) :=
  theorem_tail_with_summability hp hp11 ha hb hab

example {p : ℕ} (hp : p.Prime) (hp11 : 11 ≤ p) {a b : ℤ}
    (ha : IsingBulk.PrimeFamily.Admissible p a)
    (hb : IsingBulk.PrimeFamily.Admissible p b) (hab : a ≠ b) :
    ¬ HasExteriorCkExtension exteriorNormalizedBulk
      (IsingBulk.PrimeFamily.selectedPoint p a b) ((2*p)^2/2-1) :=
  theorem_selected_no_Ck_extension hp hp11 ha hb hab


open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let expected : Array (Name × Name) := #[
    (`IsingBulk.Tail.common_all_sector_parameters, `IsingBulk.Tail.CommonAllSectorParameters),
    (`IsingBulk.Tail.originalKSNorm_le_sectors, `IsingBulk.Tail.ExactSectorNormDomination),
    (`IsingBulk.Tail.constructed_originalKSNorm_le_sectors, `IsingBulk.Tail.ExactSectorNormDomination),
    (`IsingBulk.Tail.common_intermediateKSNormWindow_radialSeriesSmall, `IsingBulk.Tail.IntermediateWindowAssembly),
    (`IsingBulk.Tail.common_intermediateKSNormWindow_littleO, `IsingBulk.Tail.IntermediateWindowAssembly),
    (`IsingBulk.Tail.common_absoluteUpperTailSmall, `IsingBulk.Tail.AbsoluteTailAssembly),
    (`IsingBulk.Tail.selected_absolute_upper_tail_small, `IsingBulk.Tail.AbsoluteTailAssembly),
    (`IsingBulk.Final.theorem_tail, `IsingBulk.Final.UnconditionalNaturalBoundary),
    (`IsingBulk.Final.theorem_conditional, `IsingBulk.Final.ConditionalNaturalBoundary),
    (`IsingBulk.Final.theorem_conditional_physical, `IsingBulk.Final.ConditionalPhysicalBoundary),
    (`IsingBulk.Final.theorem_nb, `IsingBulk.Final.UnconditionalNaturalBoundary),
    (`IsingBulk.Final.theorem_nb_physical, `IsingBulk.Final.UnconditionalNaturalBoundary),
    (`IsingBulk.First.theorem_first, `IsingBulk.First.FirstTheorem),
    (`IsingBulk.Final.theorem_tail_with_summability, `IsingBulk.Final.UnconditionalNaturalBoundary),
    (`IsingBulk.First.selected_lower_orders_fixed_radius_bounded, `IsingBulk.First.LowerOrderFixedRadius),
    (`IsingBulk.First.nonNickel_fixed_radius_radial_bound, `IsingBulk.First.NonNickelRadialBounds),
    (`IsingBulk.Tail.selected_actual_pair_bounds, `IsingBulk.Tail.SelectedFActualPairs),
    (`IsingBulk.Final.theorem_selected_no_Ck_extension, `IsingBulk.Final.UnconditionalNaturalBoundary)]
  for (name, expectedModule) in expected do
    let some info := env.find? name
      | throwError "Missing final endpoint: {name}"
    unless info.isTheorem && !info.isUnsafe do
      throwError "Endpoint is not a safe theorem: {name}"
    let some moduleIdx := env.getModuleIdxFor? name
      | throwError "Missing module origin: {name}"
    let actualModule := env.header.moduleNames[moduleIdx.toNat]!
    unless actualModule == expectedModule do
      throwError "Wrong endpoint origin: {name}; expected {expectedModule}; got {actualModule}"
    logInfo m!"ENDPOINT_ORIGIN: {name}; MODULE: {actualModule}"
    let axioms ← Lean.collectAxioms name
    for ax in axioms do
      unless ax == `propext || ax == `Classical.choice || ax == `Quot.sound do
        throwError "Unapproved endpoint axiom: {name}; {ax}"
    logInfo m!"ENDPOINT_AXIOMS: {name}; AXIOMS: {axioms}"
  logInfo m!"ENDPOINT_CHECK_PASSED: {expected.size}"
